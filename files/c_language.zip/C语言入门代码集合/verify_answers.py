# -*- coding: utf-8 -*-
"""逐题编译验证 build_all.py 里的 C 参考答案。"""
import os
import subprocess
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from build_all import DATA  # noqa: E402


def classify(entry):
    ch, num = entry[0], entry[1]
    code = entry[7].lstrip()
    if code.startswith("# ") or code.startswith("gcc "):
        return "skip", "命令/会话操作题（shell 或 gdb）"
    if '#include "' in entry[7]:
        return "skip", "多文件工程题（.h/.c 分离）"
    if "reg52.h" in entry[7] or "stm32f10x.h" in entry[7]:
        return "skip", "单片机题（需 Keil/MDK 环境）"
    return "compile", ""


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    tmpdir = tempfile.mkdtemp(prefix="cverify_")
    ok, fail, skipped = [], [], []
    for entry in DATA:
        ch, num, title = entry[0], entry[1], entry[2]
        action, reason = classify(entry)
        qid = "Q%02d.%02d %s" % (ch, num, title)
        if action == "skip":
            skipped.append((qid, reason))
            continue
        src = os.path.join(tmpdir, "q%02d_%02d.c" % (ch, num))
        exe = os.path.join(tmpdir, "q%02d_%02d.exe" % (ch, num))
        with open(src, "w", encoding="utf-8") as f:
            f.write(entry[7] + "\n")
        r = subprocess.run(
            ["gcc", "-std=c99", "-w", "-o", exe, src],
            capture_output=True, text=True, timeout=60,
            encoding="gbk", errors="replace")
        if r.returncode == 0:
            ok.append(qid)
        else:
            fail.append((qid, r.stderr.strip()[:400]))
    print("编译通过: %d / %d（其余为环境专项题跳过）" % (len(ok), len(ok) + len(fail)))
    if fail:
        print("\n--- 编译失败 ---")
        for qid, err in fail:
            print(qid)
            print(err)
            print()
    print("\n--- 跳过清单（共 %d 题）---" % len(skipped))
    for qid, reason in skipped:
        print("  %s  [%s]" % (qid, reason))


if __name__ == "__main__":
    main()
