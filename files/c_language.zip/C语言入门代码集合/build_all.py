#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""C 语言入门代码集合 · 一键生成包

仿照《入门代码集合》(Python PCC 100 题) 的组织方式生成：
  1. exercises/ 下 100 个可编译的练习骨架文件 ch01_ex01.c ~ ch20_ex05.c
  2. C语言_练习答案_100题.pdf（与 Python 版同款排版，需 reportlab）
  3. 重写上级目录的《C语言学习全流程.txt》（含 100 题完整题目与参考解答）
  4. README.txt

运行：python build_all.py
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
WORKSPACE = os.path.dirname(HERE)

# ============================================================
# 章节定义：(章号, 章名, 对应周次, 视频建议)
# ============================================================
CHAPTERS = [
    (1,  "初识 C 与开发环境",        "第 1 周",
     "鹏哥C语言：C语言概述、软件安装  https://www.bilibili.com/video/BV1Vm4y1r7jY/"),
    (2,  "变量、数据类型与输入输出", "第 2 周",
     "鹏哥C语言：数据类型、scanf/printf  https://www.bilibili.com/video/BV1Vm4y1r7jY/"),
    (3,  "运算符与表达式",           "第 3 周",
     "鹏哥C语言：运算符与表达式  https://www.bilibili.com/video/BV1Vm4y1r7jY/"),
    (4,  "分支结构",                 "第 3 周",
     "鹏哥C语言：分支语句  https://www.bilibili.com/video/BV1Vm4y1r7jY/"),
    (5,  "循环结构",                 "第 4 周",
     "鹏哥C语言：循环语句  https://www.bilibili.com/video/BV1Vm4y1r7jY/"),
    (6,  "函数与递归",               "第 5 周",
     "鹏哥C语言：函数；递归可配合黑马 C 语言对应章节  https://www.bilibili.com/video/BV1Xa4y1k7LU/"),
    (7,  "数组",                     "第 6 周",
     "鹏哥C语言：数组  https://www.bilibili.com/video/BV1Vm4y1r7jY/"),
    (8,  "字符串与字符处理",         "第 7 周",
     "鹏哥C语言：字符串；翁恺课字符串章节回炉  https://www.bilibili.com/video/BV1XZ4y1S7e1/"),
    (9,  "指针基础",                 "第 8 周",
     "鹏哥C语言：指针初阶；翁恺课指针概念讲解  https://www.bilibili.com/video/BV1Vm4y1r7jY/"),
    (10, "指针进阶",                 "第 9 周",
     "鹏哥C语言：指针进阶（重点章，建议两遍）  https://www.bilibili.com/video/BV1Vm4y1r7jY/"),
    (11, "结构体、联合与枚举",       "第 10 周",
     "鹏哥C语言：结构体  https://www.bilibili.com/video/BV1Vm4y1r7jY/"),
    (12, "动态内存管理",             "第 11 周",
     "鹏哥C语言：动态内存管理  https://www.bilibili.com/video/BV1Vm4y1r7jY/"),
    (13, "文件操作",                 "第 11 周",
     "鹏哥C语言：文件操作  https://www.bilibili.com/video/BV1Vm4y1r7jY/"),
    (14, "多文件工程与预处理",       "第 12 周",
     "鹏哥C语言：编译与链接、预处理  https://www.bilibili.com/video/BV1Vm4y1r7jY/"),
    (15, "嵌入式专题：关键字与位运算", "第 9 周",
     "鹏哥C语言：关键字章节；嵌入式面试核心  https://www.bilibili.com/video/BV1Vm4y1r7jY/"),
    (16, "数据结构：链表",           "第 13 周",
     "王道数据结构：线性表  https://www.bilibili.com/video/BV1b7411N798/"),
    (17, "数据结构：栈与队列",       "第 14 周",
     "王道数据结构：栈和队列  https://www.bilibili.com/video/BV1b7411N798/"),
    (18, "排序与查找",               "第 14 周",
     "王道数据结构：排序、查找  https://www.bilibili.com/video/BV1b7411N798/"),
    (19, "Linux 工具链与系统调用",   "第 15 周",
     "韩顺平一周学会Linux：gcc/gdb/Makefile 章节  https://www.bilibili.com/video/BV1Sv411r7vd/"),
    (20, "单片机入门（51 → STM32）", "第 16 周",
     "江协科技51单片机（前15集）https://www.bilibili.com/video/BV1Mb411e7re/  STM32预览 https://www.bilibili.com/video/BV1th411z7sn/"),
]

DIFF_NAMES = {1: "入门", 2: "基础", 3: "进阶", 4: "提高", 5: "挑战"}

# ============================================================
# 100 题数据：(ch, num, 题名, 难度, 知识点, 题目, 示例输出, 参考解答)
# ============================================================
DATA = [

# ============ 第 1 章 初识 C 与开发环境 ============
(1, 1, "Hello World", 1, "printf 函数、程序结构",
 '用一行代码在终端打印出 "Hello World!"。',
 'Hello World!',
 r'''#include <stdio.h>

int main(void)
{
    printf("Hello World!\n");
    return 0;
}'''),

(1, 2, "多行自我介绍", 1, "printf、换行符 \\n",
 '用三条 printf 语句打印三行：第一行 "Hello, C!"，第二行你的名字和目标，第三行今天日期。',
 'Hello, C!\n我叫XXX，目标是嵌入式工程师。\n2026-08-29',
 r'''#include <stdio.h>

int main(void)
{
    printf("Hello, C!\n");
    printf("我叫XXX，目标是嵌入式工程师。\n");
    printf("2026-08-29\n");
    return 0;
}'''),

(1, 3, "认识编译报错", 2, "编译流程、看报错定位问题",
 '操作题：1) 故意删掉某行末尾的分号并编译，观察报错；2) 把 printf 拼错成 print 并编译，观察报错；3) 全部改回正确。要求记录：报错信息长什么样、报错行号指向哪里。',
 '',
 r'''/* 本题是操作题。参考解答 = 观察要点清单 + 修复后的正确代码。

   观察要点：
   1) 删掉分号 → 报 "syntax error" 类错误，报错行号常指向“下一行”，
      因为编译器读到下一行才发现上一行没结束；
   2) printf 拼错 → 报 "undefined identifier"（未定义的标识符），
      说明编译器不认识这个名字；
   3) 记住排错套路：看第一条报错 → 双击跳转行号 → 修复 → 重新编译。
      一个根源往往产生 N 条报错信息，从第一条开始解决。

   修复后的正确代码： */
#include <stdio.h>

int main(void)
{
    printf("Hello, C!\n");
    return 0;
}'''),

(1, 4, "printf 字符画", 2, "printf、循环前的暴力输出",
 '用三条 printf 语句打印出下面的星号三角形。',
 '*\n**\n***',
 r'''#include <stdio.h>

int main(void)
{
    printf("*\n");
    printf("**\n");
    printf("***\n");
    return 0;
}'''),

(1, 5, "一行计算器", 3, "占位符 %d、运算优先级、%% 转义",
 '只用一条 printf，同时输出下面四个式子的计算结果（提示：想在 printf 的格式串里打印一个百分号本身，要写 %%）。\n3+4*2=11   (3+4)*2=14   10/3=3   10%3=1',
 '3+4*2=11 (3+4)*2=14 10/3=3 10%3=1',
 r'''#include <stdio.h>

int main(void)
{
    printf("3+4*2=%d (3+4)*2=%d 10/3=%d 10%%3=%d\n",
           3 + 4 * 2, (3 + 4) * 2, 10 / 3, 10 % 3);
    return 0;
}
/* 解析：乘法优先级高于加法；printf 里输出百分号本身要用 %% */'''),

# ============ 第 2 章 变量、数据类型与输入输出 ============
(2, 1, "圆的面积与周长", 1, "scanf、double、格式化输出",
 '输入半径 r（可能带小数），输出面积和周长，各保留 2 位小数。PI 用宏定义 3.14159。',
 '输入: 2.5\n输出: 面积=19.63 周长=15.71',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#define PI 3.14159

int main(void)
{
    double r;
    scanf("%lf", &r);
    printf("面积=%.2f 周长=%.2f\n", PI * r * r, 2 * PI * r);
    return 0;
}
/* 解析：double 用 %lf 读入；scanf 必须带 & 取地址 */'''),

(2, 2, "BMI 计算器", 2, "double 运算、格式化",
 '输入身高（米）和体重（千克），输出 BMI 值（体重除以身高的平方），保留 1 位小数。',
 '输入: 1.75 68\n输出: BMI = 22.2',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

int main(void)
{
    double h, w;
    scanf("%lf %lf", &h, &w);
    printf("BMI = %.1f\n", w / (h * h));
    return 0;
}'''),

(2, 3, "char 与 ASCII", 2, "char 类型、%c 与 %d、字符运算",
 '输入一个小写字母，输出：这个字母本身、它的 ASCII 码、它对应的大写字母（提示：大小写 ASCII 码相差 32）。',
 '输入: a\n输出: 字母=a ASCII=97 大写=A',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

int main(void)
{
    char c;
    scanf(" %c", &c);        /* %c 前的空格用来跳过换行等空白 */
    printf("字母=%c ASCII=%d 大写=%c\n", c, c, c - 32);
    return 0;
}'''),

(2, 4, "秒数转换", 3, "整除与取余的综合运用",
 '输入一个总秒数，把它换算成“小时 分 秒”并输出。',
 '输入: 7265\n输出: 2小时1分5秒',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

int main(void)
{
    int total, h, m, s;
    scanf("%d", &total);
    h = total / 3600;
    m = total % 3600 / 60;
    s = total % 60;
    printf("%d小时%d分%d秒\n", h, m, s);
    return 0;
}'''),

(2, 5, "数据类型观察员", 4, "sizeof、指针大小的本质",
 '打印 char、int、double、int*、double* 各占多少字节。并回答思考题：为什么 int* 和 double* 大小相同？',
 '',
 r'''#include <stdio.h>

int main(void)
{
    printf("char    = %zu 字节\n", sizeof(char));
    printf("int     = %zu 字节\n", sizeof(int));
    printf("double  = %zu 字节\n", sizeof(double));
    printf("int*    = %zu 字节\n", sizeof(int *));
    printf("double* = %zu 字节\n", sizeof(double *));
    return 0;
}
/* 思考题答案：所有指针都是“存地址”的变量，同一平台上地址的
   长度固定（32 位系统 4 字节、64 位系统 8 字节），与指向什么
   类型无关。指向类型不同，只影响解引用时读取多少字节。 */'''),

# ============ 第 3 章 运算符与表达式 ============
(3, 1, "整数除法的陷阱", 1, "除法 / 与取余 %",
 '输出 5/2、5.0/2、(double)5/2、5%%2 四个表达式的结果，每行一个，并在代码注释里解释为什么前两个结果不同。',
 '5/2 = 2\n5.0/2 = 2.5\n(double)5/2 = 2.5\n5%2 = 1',
 r'''#include <stdio.h>

int main(void)
{
    printf("5/2 = %d\n", 5 / 2);              /* 2：两个整数相除，舍去小数 */
    printf("5.0/2 = %.1f\n", 5.0 / 2);        /* 2.5：有浮点数参与就是浮点除法 */
    printf("(double)5/2 = %.1f\n", (double)5 / 2);  /* 2.5：强制转换后再除 */
    printf("5%%2 = %d\n", 5 % 2);             /* 1：取余 */
    return 0;
}'''),

(3, 2, "自增自减", 2, "a++ 与 ++a 的区别",
 '设 a=5，依次执行 b = a++;  c = ++a;  输出 b、c、a 的值，并用注释说明每一步发生了什么。',
 'b=5 c=7 a=7',
 r'''#include <stdio.h>

int main(void)
{
    int a = 5, b, c;
    b = a++;   /* 先用后加：b 拿到 5，然后 a 变 6 */
    c = ++a;   /* 先加后用：a 变 7，然后 c 拿到 7 */
    printf("b=%d c=%d a=%d\n", b, c, a);
    return 0;
}'''),

(3, 3, "交换两个变量", 2, "赋值与临时变量",
 '输入两个整数 a、b，交换后输出。选做：不用第三个变量完成交换（加减法技巧）。',
 '输入: 3 5\n输出: a=5 b=3',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

int main(void)
{
    int a, b, t;
    scanf("%d %d", &a, &b);
    t = a; a = b; b = t;
    printf("a=%d b=%d\n", a, b);
    /* 选做（不用临时变量）：
       a = a + b; b = a - b; a = a - b; */
    return 0;
}'''),

(3, 4, "复合赋值表演", 3, "+= -= *= /= %=",
 '设 x=10，依次执行 x += 5、x -= 3、x *= 2、x /= 4、x %%= 3，每步之后打印一次 x 的值，观察结果。',
 '',
 r'''#include <stdio.h>

int main(void)
{
    int x = 10;
    x += 5; printf("x += 5 -> %d\n", x);
    x -= 3; printf("x -= 3 -> %d\n", x);
    x *= 2; printf("x *= 2 -> %d\n", x);
    x /= 4; printf("x /= 4 -> %d\n", x);   /* 整数除法：24/4=6 */
    x %= 3; printf("x %%= 3 -> %d\n", x);   /* 6%3=0 */
    return 0;
}'''),

(3, 5, "三位数反转", 4, "位值拆解、运算优先级",
 '输入一个三位正整数（如 123），输出它的反序数（321）。要求用取余和除法拆位，不许转成字符串。',
 '输入: 123\n输出: 321',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

int main(void)
{
    int n;
    scanf("%d", &n);
    /* 个位*100 + 十位*10 + 百位 */
    printf("%d\n", n % 10 * 100 + n / 10 % 10 * 10 + n / 100);
    return 0;
}'''),

# ============ 第 4 章 分支结构 ============
(4, 1, "判断奇偶", 1, "if-else",
 '输入一个整数，判断它是奇数还是偶数并输出。',
 '输入: 7\n输出: 奇数',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

int main(void)
{
    int n;
    scanf("%d", &n);
    if (n % 2 == 0) printf("偶数\n");
    else            printf("奇数\n");
    return 0;
}'''),

(4, 2, "闰年判断", 2, "逻辑运算符 && ||",
 '输入年份，判断是否闰年。规则：能被 4 整除但不能被 100 整除，或能被 400 整除。',
 '输入: 2024\n输出: 是闰年',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

int main(void)
{
    int year;
    scanf("%d", &year);
    if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)
        printf("是闰年\n");
    else
        printf("不是闰年\n");
    return 0;
}
/* 2000 年是闰年（400 整除），1900 年不是（100 整除但 400 不整除） */'''),

(4, 3, "BMI 健康分级", 3, "if-else if 多分支链",
 '输入身高体重，计算 BMI 并分级输出：< 18.5 偏瘦；18.5~23.9 正常；24~27.9 偏胖；≥ 28 肥胖。',
 '输入: 1.75 80\n输出: BMI=26.1 偏胖',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

int main(void)
{
    double h, w, bmi;
    scanf("%lf %lf", &h, &w);
    bmi = w / (h * h);
    if (bmi < 18.5)      printf("BMI=%.1f 偏瘦\n", bmi);
    else if (bmi < 24.0) printf("BMI=%.1f 正常\n", bmi);
    else if (bmi < 28.0) printf("BMI=%.1f 偏胖\n", bmi);
    else                 printf("BMI=%.1f 肥胖\n", bmi);
    return 0;
}'''),

(4, 4, "简易计算器", 4, "switch-case、异常输入处理",
 '输入格式为“数字 运算符 数字”（如 3.5 * 2），用 switch 实现加减乘除。要求：除数为 0 时输出提示；运算符不是加减乘除时输出“不支持的运算符”。',
 '输入: 3.5 * 2\n输出: 7.00',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

int main(void)
{
    double a, b;
    char op;
    scanf("%lf %c %lf", &a, &op, &b);
    switch (op) {
    case '+': printf("%.2f\n", a + b); break;
    case '-': printf("%.2f\n", a - b); break;
    case '*': printf("%.2f\n", a * b); break;
    case '/':
        if (b == 0) printf("除数不能为0\n");
        else        printf("%.2f\n", a / b);
        break;
    default:  printf("不支持的运算符\n");
    }
    return 0;
}'''),

(4, 5, "阶梯电价", 5, "分段计价（易错：不是整体套一个费率）",
 '某地阶梯电价：每月 200 度以内 0.5 元/度；超出 200 但不超过 400 的部分 0.6 元/度；超过 400 的部分 0.8 元/度。输入用电量，输出电费（保留 2 位小数）。',
 '输入: 450\n输出: 260.00',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

int main(void)
{
    int kwh;
    double fee;
    scanf("%d", &kwh);
    if (kwh <= 200)
        fee = kwh * 0.5;
    else if (kwh <= 400)
        fee = 200 * 0.5 + (kwh - 200) * 0.6;      /* 只对超出部分涨价 */
    else
        fee = 200 * 0.5 + 200 * 0.6 + (kwh - 400) * 0.8;
    printf("%.2f\n", fee);
    return 0;
}
/* 验证 450 度：100 + 120 + 40 = 260.00 元 */'''),

# ============ 第 5 章 循环结构 ============
(5, 1, "while 求和", 1, "while 循环、累加器",
 '用 while 循环计算 1+2+...+100 的和并输出。',
 'sum=5050',
 r'''#include <stdio.h>

int main(void)
{
    int i = 1, sum = 0;
    while (i <= 100) {
        sum += i;
        i++;
    }
    printf("sum=%d\n", sum);
    return 0;
}'''),

(5, 2, "7 的倍数之和", 2, "for 循环、条件筛选",
 '求 1~100 中所有 7 的倍数之和并输出。',
 'sum=735',
 r'''#include <stdio.h>

int main(void)
{
    int i, sum = 0;
    for (i = 7; i <= 100; i += 7)   /* 步长 7，比逐个判断更高效 */
        sum += i;
    printf("sum=%d\n", sum);
    return 0;
}'''),

(5, 3, "九九乘法表", 3, "嵌套循环、格式化对齐",
 '打印下三角九九乘法表。第 i 行打印 i 个式子，每个式子占 4 格左对齐。',
 '1*1=1\n1*2=2   2*2=4\n1*3=3   2*3=6   3*3=9\n（后面略）',
 r'''#include <stdio.h>

int main(void)
{
    int i, j;
    for (i = 1; i <= 9; i++) {
        for (j = 1; j <= i; j++)
            printf("%d*%d=%-4d", j, i, i * j);
        printf("\n");
    }
    return 0;
}
/* 解析：内层循环上限是 i 形成三角形；%-4d 左对齐占 4 位让列对齐 */'''),

(5, 4, "猜数字游戏", 4, "while(1)、多分支、随机数",
 '程序随机生成 1~100 的整数，用户反复输入猜测，程序提示“大了/小了”，猜中后输出总次数并结束。',
 '',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void)
{
    int answer, guess, count = 0;
    srand((unsigned)time(NULL));
    answer = rand() % 100 + 1;      /* 映射到 1~100 */
    while (1) {
        printf("请猜一个1~100之间的整数：");
        scanf("%d", &guess);
        count++;
        if (guess > answer)      printf("大了\n");
        else if (guess < answer) printf("小了\n");
        else { printf("答对了！共猜了%d次\n", count); break; }
    }
    return 0;
}'''),

(5, 5, "星号金字塔", 5, "嵌套循环、空格与数量的关系",
 '输入层数 n（如 5），打印由 * 组成的居中金字塔。第 i 行有 (n-i) 个空格和 (2i-1) 个星号。',
 '输入: 4\n输出:\n   *\n  ***\n *****\n*******',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

int main(void)
{
    int n, i, j;
    scanf("%d", &n);
    for (i = 1; i <= n; i++) {
        for (j = 0; j < n - i; j++)     printf(" ");
        for (j = 0; j < 2 * i - 1; j++) printf("*");
        printf("\n");
    }
    return 0;
}'''),

# ============ 第 6 章 函数与递归 ============
(6, 1, "三数最大值", 1, "函数定义、返回值、函数嵌套调用",
 '写函数 int my_max(int a, int b) 返回较大值，在 main 中输入三个整数，用嵌套调用求出最大值。',
 '输入: 3 9 5\n输出: max=9',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

int my_max(int a, int b)
{
    return a > b ? a : b;
}

int main(void)
{
    int a, b, c;
    scanf("%d %d %d", &a, &b, &c);
    printf("max=%d\n", my_max(my_max(a, b), c));
    return 0;
}'''),

(6, 2, "素数判断函数", 2, "函数封装、循环优化",
 '写函数 int is_prime(int n) 判断素数（只需试除到根号 n），在 main 中输出 100 以内全部素数。',
 '',
 r'''#include <stdio.h>

int is_prime(int n)
{
    int i;
    if (n < 2) return 0;
    for (i = 2; i * i <= n; i++)    /* 只试除到 sqrt(n) */
        if (n % i == 0) return 0;
    return 1;
}

int main(void)
{
    int i;
    for (i = 2; i <= 100; i++)
        if (is_prime(i)) printf("%d ", i);
    printf("\n");
    return 0;
}'''),

(6, 3, "阶乘双版本", 3, "循环与递归的对照",
 '分别用循环和递归写两个阶乘函数（long long 返回类型，防止溢出），输入 n，输出两个版本的结果。',
 '输入: 10\n输出: 循环版 10! = 3628800\n      递归版 10! = 3628800',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

long long fact_loop(int n)
{
    long long r = 1;
    int i;
    for (i = 2; i <= n; i++) r *= i;
    return r;
}

long long fact_rec(int n)
{
    if (n <= 1) return 1;
    return n * fact_rec(n - 1);
}

int main(void)
{
    int n;
    scanf("%d", &n);
    printf("循环版 %d! = %lld\n", n, fact_loop(n));
    printf("递归版 %d! = %lld\n", n, fact_rec(n));
    return 0;
}'''),

(6, 4, "斐波那契数列", 4, "递归、性能意识",
 '写递归函数 int fib(int n)（第 1、2 项为 1，之后每项等于前两项之和），输出前 20 项。思考：为什么 fib(40) 会非常慢？把思考写在注释里。',
 '1 1 2 3 5 8 13 21 34 55 89 144 ...',
 r'''#include <stdio.h>

int fib(int n)
{
    if (n == 1 || n == 2) return 1;
    return fib(n - 1) + fib(n - 2);
}

int main(void)
{
    int i;
    for (i = 1; i <= 20; i++)
        printf("%d ", fib(i));
    printf("\n");
    /* 思考：fib(40) 慢是因为递归中同一个值被反复计算了指数次
       （比如 fib(38) 算了两遍、fib(37) 算了三遍……）。
       优化方向：用数组保存已算过的值（记忆化），或直接用循环。 */
    return 0;
}'''),

(6, 5, "汉诺塔", 5, "递归经典问题",
 '输入盘子数 n，输出把 n 个盘子从 A 柱移到 C 柱的每一步（A -> C 这种格式）以及总步数。',
 '输入: 3\n输出: A -> C / A -> B / C -> B / A -> C / B -> A / B -> C / A -> C（共 7 步）',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

int steps = 0;   /* 全局计数器 */

void hanoi(int n, char from, char via, char to)
{
    if (n == 0) return;
    hanoi(n - 1, from, to, via);   /* 先把上面 n-1 个挪到中转柱 */
    steps++;
    printf("第%d步: 盘%d %c -> %c\n", steps, n, from, to);
    hanoi(n - 1, via, from, to);   /* 再把 n-1 个从中转柱挪到目标柱 */
}

int main(void)
{
    int n;
    scanf("%d", &n);
    hanoi(n, 'A', 'B', 'C');
    printf("共移动 %d 次\n", steps);   /* 2^n - 1 */
    return 0;
}'''),

# ============ 第 7 章 数组 ============
(7, 1, "最值与平均", 1, "数组输入、遍历统计",
 '输入 10 个整数存入数组，输出最大值、最小值和平均值（保留 2 位小数）。',
 '输入: 4 9 2 8 1 7 5 6 3 10\n输出: max=10 min=1 avg=5.50',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

int main(void)
{
    int a[10], i, max, min;
    double sum = 0;
    for (i = 0; i < 10; i++) scanf("%d", &a[i]);
    max = min = a[0];          /* 用第一个元素初始化最稳妥 */
    for (i = 0; i < 10; i++) {
        if (a[i] > max) max = a[i];
        if (a[i] < min) min = a[i];
        sum += a[i];
    }
    printf("max=%d min=%d avg=%.2f\n", max, min, sum / 10);
    return 0;
}'''),

(7, 2, "数组逆置", 2, "双下标向中间靠拢",
 '输入 10 个整数存入数组，写函数 void reverse(int a[], int n) 把数组原地逆置（不许用第二个数组），main 中输出逆置结果。',
 '输入: 1 2 3 4 5 6 7 8 9 10\n输出: 10 9 8 7 6 5 4 3 2 1',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

void reverse(int a[], int n)
{
    int i = 0, j = n - 1;
    while (i < j) {
        int t = a[i]; a[i] = a[j]; a[j] = t;
        i++; j--;
    }
}

int main(void)
{
    int a[10], i;
    for (i = 0; i < 10; i++) scanf("%d", &a[i]);
    reverse(a, 10);
    for (i = 0; i < 10; i++) printf("%d ", a[i]);
    printf("\n");
    return 0;
}'''),

(7, 3, "分数段统计", 3, "遍历 + 多分支计数",
 '先输入人数 n，再输入 n 个成绩（0~100），统计五段人数：90-100、80-89、70-79、60-69、60 以下，输出各段人数。',
 '',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

int main(void)
{
    int n, x, i;
    int cnt[5] = {0};   /* 依次对应 90-100/80-89/70-79/60-69/<60 */
    scanf("%d", &n);
    for (i = 0; i < n; i++) {
        scanf("%d", &x);
        if (x >= 90)      cnt[0]++;
        else if (x >= 80) cnt[1]++;
        else if (x >= 70) cnt[2]++;
        else if (x >= 60) cnt[3]++;
        else              cnt[4]++;
    }
    printf("90-100:%d 80-89:%d 70-79:%d 60-69:%d <60:%d\n",
           cnt[0], cnt[1], cnt[2], cnt[3], cnt[4]);
    return 0;
}'''),

(7, 4, "顺序查找", 4, "遍历查找、提前退出",
 '输入 10 个整数和目标值 x，输出 x 在数组中第一次出现的下标；找不到输出 -1。',
 '输入: 4 9 2 8 1 7 5 6 3 10 和 7\n输出: 5',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

int main(void)
{
    int a[10], i, x, pos = -1;
    for (i = 0; i < 10; i++) scanf("%d", &a[i]);
    scanf("%d", &x);
    for (i = 0; i < 10; i++) {
        if (a[i] == x) { pos = i; break; }   /* 找到就提前退出 */
    }
    printf("%d\n", pos);
    return 0;
}'''),

(7, 5, "矩阵转置", 5, "二维数组、行列互换",
 '输入一个 3×3 的整数矩阵，输出它的转置（第 i 行第 j 列变成第 j 行第 i 列）。',
 '输入:\n1 2 3\n4 5 6\n7 8 9\n输出:\n1 4 7\n2 5 8\n3 6 9',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

int main(void)
{
    int a[3][3], i, j;
    for (i = 0; i < 3; i++)
        for (j = 0; j < 3; j++)
            scanf("%d", &a[i][j]);
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++)
            printf("%d ", a[j][i]);   /* 行列下标互换 */
        printf("\n");
    }
    return 0;
}'''),

# ============ 第 8 章 字符串与字符处理 ============
(8, 1, "统计元音字母", 1, "遍历字符串、多条件判断",
 '输入一个不含空格的英文单词，统计其中元音字母（a e i o u，含大写）的个数。',
 '输入: Education\n输出: 5',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

int main(void)
{
    char s[100];
    int i, cnt = 0;
    scanf("%99s", s);         /* %99s 防止越界 */
    for (i = 0; s[i] != '\0'; i++) {
        char c = s[i];
        if (c=='a'||c=='e'||c=='i'||c=='o'||c=='u'||
            c=='A'||c=='E'||c=='I'||c=='O'||c=='U')
            cnt++;
    }
    printf("%d\n", cnt);
    return 0;
}'''),

(8, 2, "手写 my_strlen", 2, "'\\0' 结尾的本质",
 '不使用 string.h，自己实现 int my_strlen(const char *s)，返回字符串长度。用几组数据测试。',
 '',
 r'''#include <stdio.h>

int my_strlen(const char *s)
{
    int len = 0;
    while (s[len] != '\0') len++;
    return len;
}

int main(void)
{
    printf("%d\n", my_strlen("hello"));   /* 5 */
    printf("%d\n", my_strlen(""));        /* 0 */
    return 0;
}
/* 解析：字符串一切操作的核心都是“走到 '\0' 为止” */'''),

(8, 3, "手写 my_strcpy", 3, "逐字符复制、结束符",
 '不使用 string.h，实现 void my_strcpy(char *dst, const char *src)。特别注意复制完必须补上 \'\\0\'。',
 '',
 r'''#include <stdio.h>

void my_strcpy(char *dst, const char *src)
{
    int i = 0;
    while (src[i] != '\0') {
        dst[i] = src[i];
        i++;
    }
    dst[i] = '\0';        /* 忘了这一行是最经典的 bug */
}

int main(void)
{
    char dst[20];
    my_strcpy(dst, "embedded C");
    printf("%s\n", dst);
    return 0;
}'''),

(8, 4, "回文串判断", 4, "双指针、大小写统一",
 '输入一个英文单词，忽略大小写判断它是否是回文（正读反读一样，如 Level、noon）。',
 '输入: Level\n输出: 是回文',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

int main(void)
{
    char s[100];
    int i = 0, j, ok = 1;
    scanf("%99s", s);
    for (i = 0; s[i] != '\0'; i++)          /* 统一转小写 */
        if (s[i] >= 'A' && s[i] <= 'Z') s[i] += 32;
    j = 0;
    while (s[j] != '\0') j++;               /* j 指向结束符 */
    j--;                                    /* j 指向最后一个字符 */
    i = 0;
    while (i < j) {
        if (s[i] != s[j]) { ok = 0; break; }
        i++; j--;
    }
    printf(ok ? "是回文\n" : "不是回文\n");
    return 0;
}'''),

(8, 5, "统计单词个数", 5, "fgets、状态标记法",
 '输入一行英文（可能含多个连续空格，用 fgets 读取整行），统计其中单词个数。技巧：用一个“当前是否在单词内”的标记，从空格进入字母时计数加一。',
 '输入: hello   embedded   world\n输出: 3',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

int main(void)
{
    char line[200];
    int i, words = 0, in_word = 0;
    fgets(line, sizeof(line), stdin);
    for (i = 0; line[i] != '\0'; i++) {
        if (line[i] != ' ' && line[i] != '\n' && line[i] != '\t') {
            if (!in_word) { words++; in_word = 1; }
        } else {
            in_word = 0;
        }
    }
    printf("%d\n", words);
    return 0;
}'''),

# ============ 第 9 章 指针基础 ============
(9, 1, "指针版 swap", 1, "指针传参、解引用",
 '写函数 void swap(int *a, int *b)，在 main 中交换两个变量并打印验证。再想想：如果参数是普通 int 为什么不行？',
 '输入: 3 5\n输出: x=5 y=3',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

void swap(int *a, int *b)
{
    int t = *a; *a = *b; *b = t;
}

int main(void)
{
    int x = 3, y = 5;
    swap(&x, &y);
    printf("x=%d y=%d\n", x, y);
    return 0;
}
/* 解析：传地址后函数拿到“变量的家”才能真正修改它；
   传普通 int 只是把值拷贝了一份，改的是副本 */'''),

(9, 2, "认识地址与指针", 1, "&、*、%p、sizeof",
 '定义 int a = 42; int *p = &a;，依次打印：a 的值、a 的地址、p 里存的地址、*p 的值、p 的大小。观察 p 和 &a 的关系。',
 '',
 r'''#include <stdio.h>

int main(void)
{
    int a = 42;
    int *p = &a;
    printf("a        = %d\n", a);
    printf("&a       = %p\n", (void *)&a);
    printf("p        = %p\n", (void *)p);   /* 与 &a 相同 */
    printf("*p       = %d\n", *p);
    printf("sizeof(p)= %zu\n", sizeof(p));  /* 指针大小固定 */
    return 0;
}'''),

(9, 3, "三个数找最大（指针版）", 2, "解引用比较、指针换向",
 '输入三个整数，但禁止直接比较变量名：必须让指针 pmax 指向其中最大者，最后通过 *pmax 输出最大值。',
 '输入: 3 9 5\n输出: max=9',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

int main(void)
{
    int a, b, c;
    int *pmax;
    scanf("%d %d %d", &a, &b, &c);
    pmax = &a;
    if (*pmax < b) pmax = &b;
    if (*pmax < c) pmax = &c;
    printf("max=%d\n", *pmax);
    return 0;
}'''),

(9, 4, "野指针与 NULL", 3, "指针安全规范",
 '先分析下面的错误代码为什么危险，再写出两种正确写法：\n  int *p;\n  *p = 10;',
 '',
 r'''/* 分析：p 定义时没初始化，里面是随机垃圾值（野指针），
   *p = 10 会把 10 写进一个未知的内存位置，轻则数据被毁、重则崩溃。
   规范：定义指针时立刻初始化；暂时不用就置 NULL。 */
#include <stdio.h>

int main(void)
{
    /* 正确写法一：指向已有变量 */
    int a;
    int *p = &a;
    *p = 10;
    printf("*p=%d\n", *p);

    /* 正确写法二：暂不指向任何地方，用 NULL 占位，用前判空 */
    int *q = NULL;
    if (q != NULL) *q = 10;    /* 判空保护，q 现在不会被执行 */
    return 0;
}'''),

(9, 5, "指针遍历数组求和", 4, "指针运算、p++ 的含义",
 '定义数组 {1,2,3,4,5}，只用指针（禁止使用下标 []）遍历数组求和并输出。',
 'sum=15',
 r'''#include <stdio.h>

int main(void)
{
    int a[5] = {1, 2, 3, 4, 5};
    int *p, sum = 0;
    for (p = a; p < a + 5; p++)   /* a 即首元素地址 */
        sum += *p;
    printf("sum=%d\n", sum);
    return 0;
}
/* 解析：p++ 每次跳过 1 个 int 的字节数，这正是“指针类型”的意义 */'''),

# ============ 第 10 章 指针进阶 ============
(10, 1, "a[i] 与 *(a+i)", 1, "数组名退化、下标与指针等价",
 '定义数组 {10,20,30,40,50}，用 a[i] 和 *(a+i) 两种方式在同一行打印每个元素，验证它们等价。',
 '',
 r'''#include <stdio.h>

int main(void)
{
    int a[5] = {10, 20, 30, 40, 50};
    int i;
    for (i = 0; i < 5; i++)
        printf("a[%d]=%d  *(a+%d)=%d\n", i, a[i], i, *(a + i));
    return 0;
}'''),

(10, 2, "返回指针的函数", 2, "int* 返回值",
 '写函数 int *max_element(int a[], int n) 返回数组中最大元素的地址，main 中通过该地址打印最大值。',
 '',
 r'''#include <stdio.h>

int *max_element(int a[], int n)
{
    int *pmax = &a[0], i;
    for (i = 1; i < n; i++)
        if (a[i] > *pmax) pmax = &a[i];
    return pmax;
}

int main(void)
{
    int a[6] = {4, 9, 2, 8, 1, 7};
    printf("max=%d\n", *max_element(a, 6));
    return 0;
}'''),

(10, 3, "二级指针", 3, "int**、通过函数修改指针本身",
 '写函数 void set_ptr(int **pp, int *newp)，让它把指针 p 的指向从 &x 改成 &y。想改普通变量传 int*，想改指针变量就要传 int**。',
 '',
 r'''#include <stdio.h>

void set_ptr(int **pp, int *newp)
{
    *pp = newp;      /* 解一次引用，改的是 p 本身的值 */
}

int main(void)
{
    int x = 10, y = 20;
    int *p = &x;
    set_ptr(&p, &y);
    printf("%d\n", *p);    /* 输出 20，说明 p 已改指 y */
    return 0;
}'''),

(10, 4, "函数指针", 4, "函数指针、回调思想",
 '写 add 和 sub 两个函数。main 中定义函数指针 int (*fp)(int, int)，根据变量 op 的值让它指向 add 或 sub，再统一用 fp(3, 4) 调用并输出。',
 '',
 r'''#include <stdio.h>

int add(int a, int b) { return a + b; }
int sub(int a, int b) { return a - b; }

int main(void)
{
    int (*fp)(int, int);
    char op = '+';              /* 改成 '-' 试试 */
    if (op == '+') fp = add;
    else           fp = sub;
    printf("3 %c 4 = %d\n", op, fp(3, 4));
    return 0;
}
/* 解析：嵌入式里中断回调、驱动 ops 结构体全靠函数指针 */'''),

(10, 5, "模拟寄存器访问", 5, "嵌入式预科、指针直访内存",
 '嵌入式开发常用指针直接访问固定地址。在 PC 上模拟：定义 unsigned int reg，让指针 p 指向它，用位运算把第 3 位置 1 再清 0，并打印 reg 的值和 reg 的地址。',
 '',
 r'''#include <stdio.h>

int main(void)
{
    unsigned int reg = 0x00000000;
    unsigned int *p = &reg;      /* 让 p 指向 reg */

    *p |= (1u << 3);             /* 第 3 位置 1 */
    printf("reg=0x%08X\n", reg); /* 0x00000008 */
    printf("addr=%p\n", (void *)&reg);

    *p &= ~(1u << 3);            /* 第 3 位清 0 */
    printf("reg=0x%08X\n", reg); /* 0x00000000 */
    return 0;
}
/* 真实单片机上写 volatile unsigned int *p =
   (unsigned int *)0x4001080C; 就是同一套逻辑，只是地址由芯片手册规定 */'''),

# ============ 第 11 章 结构体、联合与枚举 ============
(11, 1, "学生结构体", 1, "struct、typedef、成员访问",
 '定义 Student 结构体（姓名、年龄、成绩），输入 3 名学生信息，再按格式输出。',
 '',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

typedef struct {
    char   name[20];
    int    age;
    double score;
} Student;

int main(void)
{
    Student s[3];
    int i;
    for (i = 0; i < 3; i++)
        scanf("%19s %d %lf", s[i].name, &s[i].age, &s[i].score);
    for (i = 0; i < 3; i++)
        printf("%s %d %.1f\n", s[i].name, s[i].age, s[i].score);
    return 0;
}
/* 解析：数组名本身就是地址，所以 s[i].name 前不加 & */'''),

(11, 2, "按成绩排序", 2, "结构体数组、整体交换",
 '初始化 3 名学生（姓名+成绩），用冒泡思想按成绩从高到低排序后输出。',
 '',
 r'''#include <stdio.h>

typedef struct { char name[20]; int score; } Student;

int main(void)
{
    Student s[3] = {{"Tom", 85}, {"Jerry", 92}, {"Mary", 78}};
    int i, j;
    for (i = 0; i < 2; i++)
        for (j = 0; j < 2 - i; j++)
            if (s[j].score < s[j + 1].score) {
                Student t = s[j]; s[j] = s[j + 1]; s[j + 1] = t;
            }
    for (i = 0; i < 3; i++)
        printf("%s %d\n", s[i].name, s[i].score);
    return 0;
}'''),

(11, 3, "联合体判断大小端", 3, "union、字节序（嵌入式经典面试题）",
 '用 union 编程判断当前机器是大端还是小端，并说明大端小端分别是什么。',
 '',
 r'''#include <stdio.h>

union Check { int i; char c; };

int main(void)
{
    union Check u;
    u.i = 1;                 /* 内存中最低字节是 0x01 */
    if (u.c == 1) printf("小端（低字节存低地址）\n");
    else          printf("大端（高字节存低地址）\n");
    return 0;
}
/* 解析：char c 只取联合体第 1 个字节。小端机器上读到的就是 1。
   x86/Windows 是小端；网络字节序是大端，所以嵌入式通信要谈字节序 */'''),

(11, 4, "内存对齐观察", 4, "sizeof、结构体对齐规则",
 '定义 struct A { char c; int i; char d; };，打印 sizeof(struct A)，解释为什么不是 6 而是 12。选做：调整成员顺序再观察。',
 '',
 r'''#include <stdio.h>

struct A { char c; int i; char d; };

int main(void)
{
    printf("%zu\n", sizeof(struct A));   /* 通常输出 12 */
    return 0;
}
/* 解析：int 需要 4 字节对齐，char c 后面空 3 字节；整个结构体大小
   还要是最大对齐数的整数倍，末尾再补 3 字节 → 1+3+4+1+3=12。
   选做：改成 char c; char d; int i; 后 sizeof 变 8——
   排成员顺序能省内存，嵌入式内存敏感时很实用 */'''),

(11, 5, "课程表（枚举+结构体）", 5, "enum、struct 综合运用",
 '定义枚举 enum Weekday（周一到周日）和结构体 Course（课程名、星期、第几节）。初始化两门课并打印成“课程 星期 第几节”的格式。',
 '',
 r'''#include <stdio.h>

enum Weekday { MON, TUE, WED, THU, FRI, SAT, SUN };

typedef struct {
    char name[20];
    enum Weekday day;
    int  slot;          /* 第几节课 */
} Course;

int main(void)
{
    Course c[2] = { {"C语言", MON, 1}, {"单片机", WED, 3} };
    const char *w[] = {"周一","周二","周三","周四","周五","周六","周日"};
    int i;
    for (i = 0; i < 2; i++)
        printf("%s %s 第%d节\n", c[i].name, w[c[i].day], c[i].slot);
    return 0;
}'''),

# ============ 第 12 章 动态内存管理 ============
(12, 1, "malloc 动态数组求和", 1, "malloc、判空、free",
 '输入 n，用 malloc 申请 n 个 int 的空间，输入 n 个数输出它们的和，最后释放内存。',
 '',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int n, i, sum = 0;
    int *a;
    scanf("%d", &n);
    a = (int *)malloc(n * sizeof(int));
    if (a == NULL) { printf("内存申请失败\n"); return 1; }
    for (i = 0; i < n; i++) scanf("%d", &a[i]);
    for (i = 0; i < n; i++) sum += a[i];
    printf("sum=%d\n", sum);
    free(a);          /* 用完必须释放 */
    a = NULL;         /* 防止悬空指针，好习惯 */
    return 0;
}'''),

(12, 2, "realloc 追加扩容", 2, "realloc、动态增长",
 '不断输入整数（以 -1 结束），把它们全部保存到一个动态数组里（每来一个数就 realloc 多一个位置），最后输出全部内容和个数。',
 '',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int *a = NULL;
    int n = 0, x, i;
    while (scanf("%d", &x) == 1 && x != -1) {
        int *tmp = (int *)realloc(a, (n + 1) * sizeof(int));
        if (tmp == NULL) { free(a); return 1; }   /* 失败时旧的 a 还在 */
        a = tmp;
        a[n++] = x;
    }
    for (i = 0; i < n; i++) printf("%d ", a[i]);
    printf("\n共 %d 个\n", n);
    free(a);
    return 0;
}
/* 生产代码通常按“容量翻倍”扩容以减少 realloc 次数 */'''),

(12, 3, "动态拼接字符串", 3, "malloc + strlen + strcpy/strcat",
 '输入两个不含空格的字符串，动态申请一块“刚好够用”的内存，把两个串用空格拼在一起输出，最后释放。',
 '',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
    char s1[50], s2[50];
    char *merged;
    int len;
    scanf("%49s %49s", s1, s2);
    len = (int)strlen(s1) + (int)strlen(s2) + 2;  /* 空格 + '\0' */
    merged = (char *)malloc(len);
    if (merged == NULL) return 1;
    strcpy(merged, s1);
    strcat(merged, " ");
    strcat(merged, s2);
    printf("%s\n", merged);
    free(merged);
    return 0;
}'''),

(12, 4, "动态学生名册", 4, "结构体 + malloc 组合",
 '输入人数 n，动态申请 n 个 Student 结构体（姓名+分数），输入全部信息后再输出，最后释放。',
 '',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <stdlib.h>

typedef struct { char name[20]; int score; } Student;

int main(void)
{
    int n, i;
    Student *st;
    scanf("%d", &n);
    st = (Student *)malloc(n * sizeof(Student));
    if (st == NULL) return 1;
    for (i = 0; i < n; i++)
        scanf("%19s %d", st[i].name, &st[i].score);
    for (i = 0; i < n; i++)
        printf("%s %d\n", st[i].name, st[i].score);
    free(st);
    return 0;
}'''),

(12, 5, "内存泄漏找茬", 5, "泄漏、越界、悬空指针",
 '下面的代码有 3 个问题，请逐一指出并写出正确版本：\n  int *p = (int*)malloc(10 * sizeof(int));\n  for (int i = 0; i <= 10; i++) p[i] = i;\n  free(p);\n  printf("%d\\n", p[0]);',
 '',
 r'''/* 三个问题：
   1) malloc 之后没有判空（p 可能是 NULL 就直接用了）；
   2) 循环条件 i <= 10 越界：合法下标是 0~9，多写了 1 个元素，
      踩了堆管理数据，可能当时没事但埋雷；
   3) free(p) 之后又读 p[0]——悬空指针，属于未定义行为。 */
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int *p = (int *)malloc(10 * sizeof(int));
    int i;
    if (p == NULL) return 1;         /* 修复 1：判空 */
    for (i = 0; i < 10; i++)         /* 修复 2：i < 10 */
        p[i] = i;
    for (i = 0; i < 10; i++)
        printf("%d ", p[i]);
    printf("\n");
    free(p);                         /* 修复 3：free 后不再使用 */
    p = NULL;
    return 0;
}'''),

# ============ 第 13 章 文件操作 ============
(13, 1, "写入并读回数字", 1, "fopen/fprintf/fscanf、文件模式",
 '把 1~10 写入 nums.txt，再从文件里读出来求和输出。注意每次 fopen 都要判空。',
 'sum=55',
 r'''#include <stdio.h>

int main(void)
{
    FILE *fp;
    int i, x, sum = 0;
    fp = fopen("nums.txt", "w");      /* 写模式：新建/清空 */
    if (fp == NULL) return 1;
    for (i = 1; i <= 10; i++) fprintf(fp, "%d\n", i);
    fclose(fp);

    fp = fopen("nums.txt", "r");      /* 读模式 */
    if (fp == NULL) return 1;
    while (fscanf(fp, "%d", &x) == 1) /* 读到几个字段就是几 */
        sum += x;
    fclose(fp);
    printf("sum=%d\n", sum);
    return 0;
}'''),

(13, 2, "逐行读取加行号", 2, "fgets 逐行读取",
 '程序先把四句诗写入 poem.txt，再用 fgets 一行一行读回来，打印时加上行号。',
 '1: 白日依山尽\n2: 黄河入海流\n3: 欲穷千里目\n4: 更上一层楼',
 r'''#include <stdio.h>

int main(void)
{
    FILE *fp;
    char line[100];
    int no = 1;
    fp = fopen("poem.txt", "w");
    if (fp == NULL) return 1;
    fprintf(fp, "白日依山尽\n黄河入海流\n欲穷千里目\n更上一层楼\n");
    fclose(fp);

    fp = fopen("poem.txt", "r");
    if (fp == NULL) return 1;
    while (fgets(line, sizeof(line), fp) != NULL)
        printf("%d: %s", no++, line);
    fclose(fp);
    return 0;
}
/* 解析：fgets 会保留行末的 \n，所以打印时不用额外换行 */'''),

(13, 3, "统计行数与字符数", 3, "fgetc 逐字符读取、EOF",
 '程序先写入一段多行文本到 note.txt，再用 fgetc 逐字符读回，统计行数和字符数（按字节计，含换行符）。',
 '',
 r'''#include <stdio.h>

int main(void)
{
    FILE *fp;
    int ch, lines = 0, chars = 0;
    fp = fopen("note.txt", "w");
    if (fp == NULL) return 1;
    fprintf(fp, "Hello C\nembedded\nlinux\n");
    fclose(fp);

    fp = fopen("note.txt", "r");
    if (fp == NULL) return 1;
    while ((ch = fgetc(fp)) != EOF) {
        chars++;
        if (ch == '\n') lines++;
    }
    fclose(fp);
    printf("行数=%d 字符数=%d\n", lines, chars);
    return 0;
}'''),

(13, 4, "结构体二进制读写", 4, "fwrite/fread、wb/rb 模式",
 '把一个 Student 结构体数组用 fwrite 一次性写入 students.dat（二进制），再用 fread 逐条读回打印。体会二进制文件与文本文件的区别。',
 '',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

typedef struct { char name[20]; int score; } Student;

int main(void)
{
    Student w[3] = {{"Tom",85},{"Jerry",92},{"Mary",78}};
    Student r;
    FILE *fp;
    fp = fopen("students.dat", "wb");
    if (fp == NULL) return 1;
    fwrite(w, sizeof(Student), 3, fp);
    fclose(fp);

    fp = fopen("students.dat", "rb");
    if (fp == NULL) return 1;
    while (fread(&r, sizeof(Student), 1, fp) == 1)
        printf("%s %d\n", r.name, r.score);
    fclose(fp);
    return 0;
}
/* 二进制文件按内存原样存储：体积小、读写快，但人看不懂、
   且跨平台时受字节序/对齐影响——嵌入式存储数据时的经典取舍 */'''),

(13, 5, "追加日志", 5, "a 追加模式、time.h 时间戳",
 '每次运行程序，都向 log.txt 追加一行“run at <时间戳>”（用 time(NULL) 取当前时间），然后把日志文件的全部内容打印出来。多运行几次验证旧内容还在。',
 '',
 r'''#include <stdio.h>
#include <time.h>

int main(void)
{
    FILE *fp;
    char line[100];
    time_t now = time(NULL);
    fp = fopen("log.txt", "a");       /* 追加模式：不清空旧内容 */
    if (fp == NULL) return 1;
    fprintf(fp, "run at %lld\n", (long long)now);
    fclose(fp);

    fp = fopen("log.txt", "r");
    if (fp == NULL) return 1;
    while (fgets(line, sizeof(line), fp) != NULL)
        printf("%s", line);
    fclose(fp);
    return 0;
}'''),

# ============ 第 14 章 多文件工程与预处理 ============
(14, 1, "带参宏 MAX/MIN", 1, "#define 带参宏、括号陷阱",
 '定义求最大/最小值的宏 MAX(a,b)、MIN(a,b) 并测试。注意每个参数和整体都要加括号。',
 '',
 r'''#include <stdio.h>

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int main(void)
{
    printf("%d %d\n", MAX(3, 5), MIN(3, 5));   /* 5 3 */
    return 0;
}'''),

(14, 2, "头文件三件套", 2, ".h/.c 分离、#ifndef 防重复包含",
 '把 add 函数拆成三个文件：utils.h 放声明、utils.c 放实现、main.c 调用。在 VS 里把三个文件加入同一工程编译运行。',
 '',
 r'''/* ---------- utils.h ---------- */
#ifndef UTILS_H
#define UTILS_H
int add(int a, int b);
#endif

/* ---------- utils.c ---------- */
#include "utils.h"
int add(int a, int b) { return a + b; }

/* ---------- main.c ---------- */
#include <stdio.h>
#include "utils.h"
int main(void)
{
    printf("%d\n", add(2, 3));   /* 5 */
    return 0;
}
/* 解析：#ifndef 三件套防止头文件被重复包含；
   这是后续所有工程（包括单片机工程）的标准组织方式 */'''),

(14, 3, "条件编译调试开关", 3, "#ifdef、__FILE__、__LINE__",
 '用 #ifdef DEBUG 实现调试开关：定义了 DEBUG 宏时打印调试信息（含文件名和行号），否则只输出正常运行信息。把 #define DEBUG 注释掉再编译，对比效果。',
 '',
 r'''#define DEBUG          /* 注释掉这一行，调试信息就消失 */

#include <stdio.h>

int main(void)
{
    int x = 42;
#ifdef DEBUG
    printf("[DEBUG] x=%d 文件:%s 行:%d\n", x, __FILE__, __LINE__);
#endif
    printf("程序正常运行\n");
    return 0;
}'''),

(14, 4, "宏展开找茬", 4, "宏是文本替换、优先级陷阱",
 '解释为什么 #define SQR(x) x*x 在计算 SQR(1+2) 时得到 5 而不是 9，写出正确版本并用程序验证两个版本的结果。',
 '',
 r'''#include <stdio.h>

#define SQR_BAD(x)  x * x          /* 错误写法 */
#define SQR_OK(x)   ((x) * (x))    /* 正确写法 */

int main(void)
{
    printf("SQR_BAD(1+2) = %d\n", SQR_BAD(1 + 2));  /* 5 */
    /* 展开为 1 + 2 * 1 + 2 = 1 + 2 + 2 = 5 */
    printf("SQR_OK(1+2)   = %d\n", SQR_OK(1 + 2));  /* 9 */
    return 0;
}
/* 解析：宏是纯文本替换，不是函数调用。参数不加括号就会被
   运算优先级坑掉——这是笔试高频题 */'''),

(14, 5, "extern 跨文件计数器", 5, "extern、声明与定义的区别",
 '做一个跨文件的全局计数器：counter.h 用 extern 声明 g_count 和 inc 函数；counter.c 里定义它们；main.c 调用三次 inc 后打印 g_count（应为 3）。',
 '',
 r'''/* ---------- counter.h ---------- */
#ifndef COUNTER_H
#define COUNTER_H
extern int g_count;      /* 声明：告诉其他文件“它存在，在别处定义” */
void inc(void);
#endif

/* ---------- counter.c ---------- */
#include "counter.h"
int g_count = 0;         /* 定义：真正分配内存、初始化的地方 */
void inc(void) { g_count++; }

/* ---------- main.c ---------- */
#include <stdio.h>
#include "counter.h"
int main(void)
{
    inc(); inc(); inc();
    printf("g_count=%d\n", g_count);   /* 3 */
    return 0;
}'''),

# ============ 第 15 章 嵌入式专题：关键字与位运算 ============
(15, 1, "位操作四连", 1, "| 置1、& 清0、^ 翻转、>> 取位",
 '实现四个函数：对 32 位无符号数 x 的第 n 位（从 0 数）置 1、清 0、翻转、读取，并用 main 演示。',
 '',
 r'''#include <stdio.h>

unsigned int set_bit  (unsigned int x, int n) { return x |  (1u << n); }
unsigned int clear_bit(unsigned int x, int n) { return x & ~(1u << n); }
unsigned int flip_bit (unsigned int x, int n) { return x ^  (1u << n); }
unsigned int get_bit  (unsigned int x, int n) { return (x >> n) & 1u; }

int main(void)
{
    unsigned int reg = 0x00000000;
    reg = set_bit(reg, 3);
    printf("set   bit3: 0x%08X\n", reg);          /* 0x00000008 */
    reg = flip_bit(reg, 0);
    printf("flip  bit0: 0x%08X\n", reg);          /* 0x00000009 */
    printf("get   bit3: %u\n", get_bit(reg, 3));  /* 1 */
    reg = clear_bit(reg, 3);
    printf("clear bit3: 0x%08X\n", reg);          /* 0x00000001 */
    return 0;
}
/* 口诀：或 1 置一、与 0 清零、异或取反。寄存器操作天天用 */'''),

(15, 2, "const 两种指针", 2, "const int* 与 int* const",
 '分别定义 const int *p1 和 int *const p2，用注释标明各自“什么能改、什么不能改”，并把会编译报错的行写在注释里。',
 '',
 r'''#include <stdio.h>

int main(void)
{
    int a = 10, b = 20;
    const int *p1 = &a;   /* 指向常量的指针：*p1 不可改，p1 可换指向 */
    int *const p2 = &a;   /* 常量指针：p2 不可换指向，*p2 可改 */

    /* *p1 = 99;  编译报错：内容只读 */
    p1 = &b;              /* 正确：换指向 */
    printf("*p1=%d\n", *p1);

    /* p2 = &b;   编译报错：指针本身只读 */
    *p2 = 99;             /* 正确：改内容 */
    printf("a=%d\n", a);
    return 0;
}
/* 口诀：const 在 * 左边修饰内容，在 * 右边修饰指针 */'''),

(15, 3, "static 记忆效应", 3, "static 局部变量、生命周期",
 '写函数 int counter()，内部用 static 局部变量计数。main 中调用三次，输出 1 2 3，并解释 static 局部变量与普通局部变量的区别。',
 '',
 r'''#include <stdio.h>

int counter(void)
{
    static int count = 0;   /* 只初始化一次，程序结束才销毁 */
    count++;
    return count;
}

int main(void)
{
    printf("%d\n", counter());   /* 1 */
    printf("%d\n", counter());   /* 2 */
    printf("%d\n", counter());   /* 3 */
    return 0;
}
/* 解析：普通局部变量每次进函数都重新分配、出了函数就销毁；
   static 局部变量放在静态区，只初始化一次，生命周期 = 整个程序 */'''),

(15, 4, "统计二进制中 1 的个数", 4, "位运算经典题、x & (x-1) 技巧",
 '输入一个非负整数，输出它的二进制表示中 1 的个数。要求会两种方法：逐位检查法，以及经典的 x &= (x-1) 技巧。',
 '输入: 13\n输出: 3',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

int count_one(int x)
{
    int c = 0;
    while (x != 0) {
        x &= x - 1;    /* 每执行一次，消掉最低位的一个 1 */
        c++;
    }
    return c;
}

int main(void)
{
    unsigned int x;
    scanf("%u", &x);
    printf("%d\n", count_one((int)x));
    return 0;
}
/* 13 = 1101，有 3 个 1。笔试手写高频题 */'''),

(15, 5, "volatile 与中断标志", 5, "volatile、编译器优化",
 '回答：volatile 的作用是什么？举出三个必须使用的场景。然后写模拟代码：一个“等待中断置起标志”的主循环（演示时用有限次数循环代替死等）。',
 '',
 r'''#include <stdio.h>

volatile int flag = 0;   /* 模拟“中断里会被改成 1”的共享标志 */

int main(void)
{
    int i;
    printf("等待事件...\n");
    for (i = 0; i < 5 && !flag; i++) {   /* 模拟等待中断 */
        printf("等待中 %d\n", i);
        /* 真实硬件上：中断服务函数会把 flag 置 1 */
    }
    printf("结束（flag=%d）\n", flag);
    return 0;
}
/* 参考要点：
   volatile 禁止编译器把这个变量缓存在寄存器里，强制每次都从
   内存真实读取。三个必用场景：
   1) 硬件寄存器映射的指针；
   2) 中断服务程序与主程序共享的标志；
   3) 多线程/多任务共享的开关变量。
   若不加 volatile，编译器可能发现主循环里没人改 flag，
   就把它优化成只读一次 → 死循环。嵌入式面试压轴题 */'''),

# ============ 第 16 章 数据结构：链表 ============
(16, 1, "头插法建表与遍历", 1, "malloc 结点、头插、遍历",
 '实现头插函数 Node *push_front(Node *head, int x) 和打印函数，依次头插 1~5，观察输出顺序。',
 '5 4 3 2 1',
 r'''#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node *next;
} Node;

Node *push_front(Node *head, int x)
{
    Node *p = (Node *)malloc(sizeof(Node));
    p->data = x;
    p->next = head;
    return p;           /* 新结点成为新的头 */
}

void print_list(Node *head)
{
    for (; head != NULL; head = head->next)
        printf("%d ", head->data);
    printf("\n");
}

int main(void)
{
    Node *head = NULL;
    int i;
    for (i = 1; i <= 5; i++)
        head = push_front(head, i);
    print_list(head);   /* 头插法：顺序倒过来了 */
    return 0;
}'''),

(16, 2, "尾插法与求和", 2, "尾插、找尾结点",
 '实现尾插函数 Node *push_back(Node *head, int x)（新结点接到最后），依次尾插 1~5，遍历求和并输出。对比第 1 题的输出顺序。',
 '1 2 3 4 5\nsum=15',
 r'''#include <stdio.h>
#include <stdlib.h>

typedef struct Node { int data; struct Node *next; } Node;

Node *push_back(Node *head, int x)
{
    Node *p = (Node *)malloc(sizeof(Node));
    Node *cur;
    p->data = x; p->next = NULL;
    if (head == NULL) return p;
    cur = head;
    while (cur->next != NULL) cur = cur->next;  /* 走到最后一个 */
    cur->next = p;
    return head;
}

int main(void)
{
    Node *head = NULL, *cur;
    int i, sum = 0;
    for (i = 1; i <= 5; i++)
        head = push_back(head, i);
    for (cur = head; cur != NULL; cur = cur->next) {
        printf("%d ", cur->data);
        sum += cur->data;
    }
    printf("\nsum=%d\n", sum);
    return 0;
}'''),

(16, 3, "按值删除结点", 3, "虚拟头结点、先接链再 free",
 '实现 Node *delete_val(Node *head, int x)：删除第一个值为 x 的结点。用虚拟头结点技巧统一处理“删的是头结点”的情况。注意先接链再 free。',
 '',
 r'''#include <stdio.h>
#include <stdlib.h>

typedef struct Node { int data; struct Node *next; } Node;

Node *new_node(int x)
{
    Node *p = (Node *)malloc(sizeof(Node));
    p->data = x; p->next = NULL;
    return p;
}

Node *push_back(Node *head, int x)
{
    Node *p = new_node(x), *cur;
    if (head == NULL) return p;
    for (cur = head; cur->next != NULL; cur = cur->next) ;
    cur->next = p;
    return head;
}

Node *delete_val(Node *head, int x)
{
    Node dummy;              /* 虚拟头结点：删头不再特殊 */
    Node *cur = &dummy, *t;
    dummy.next = head;
    while (cur->next != NULL) {
        if (cur->next->data == x) {
            t = cur->next;
            cur->next = t->next;   /* 先接链 */
            free(t);               /* 再释放，顺序不能反 */
            break;
        }
        cur = cur->next;
    }
    return dummy.next;
}

void print_list(Node *head)
{
    for (; head != NULL; head = head->next) printf("%d ", head->data);
    printf("\n");
}

int main(void)
{
    Node *head = NULL;
    head = push_back(head, 1);
    head = push_back(head, 2);
    head = push_back(head, 3);
    head = delete_val(head, 2);
    print_list(head);        /* 1 3 */
    return 0;
}'''),

(16, 4, "链表反转", 4, "三指针迭代反转（面试高频）",
 '实现 Node *reverse(Node *head)：把链表原地反转。用 prev/cur/next 三个指针迭代完成，不许建新链表。',
 '',
 r'''#include <stdio.h>
#include <stdlib.h>

typedef struct Node { int data; struct Node *next; } Node;

Node *push_back(Node *head, int x)
{
    Node *p = (Node *)malloc(sizeof(Node)), *cur;
    p->data = x; p->next = NULL;
    if (head == NULL) return p;
    for (cur = head; cur->next != NULL; cur = cur->next) ;
    cur->next = p;
    return head;
}

Node *reverse(Node *head)
{
    Node *prev = NULL, *cur = head, *next;
    while (cur != NULL) {
        next = cur->next;    /* 1. 先记住下一个 */
        cur->next = prev;    /* 2. 反指 */
        prev = cur;          /* 3. prev 前移 */
        cur = next;          /* 4. cur 前移 */
    }
    return prev;             /* prev 就是新的头 */
}

void print_list(Node *head)
{
    for (; head != NULL; head = head->next) printf("%d ", head->data);
    printf("\n");
}

int main(void)
{
    Node *head = NULL;
    int i;
    for (i = 1; i <= 5; i++)
        head = push_back(head, i);
    head = reverse(head);
    print_list(head);        /* 5 4 3 2 1 */
    return 0;
}'''),

(16, 5, "有序插入", 5, "保持链表有序、插入位置查找",
 '实现 Node *insert_sorted(Node *head, int x)：把 x 插入升序链表的正确位置。依次插入 3、1、4、2、5，最终输出 1 2 3 4 5。',
 '1 2 3 4 5',
 r'''#include <stdio.h>
#include <stdlib.h>

typedef struct Node { int data; struct Node *next; } Node;

Node *new_node(int x)
{
    Node *p = (Node *)malloc(sizeof(Node));
    p->data = x; p->next = NULL;
    return p;
}

Node *insert_sorted(Node *head, int x)
{
    Node *p = new_node(x);
    Node dummy, *cur;
    dummy.next = head;
    cur = &dummy;
    while (cur->next != NULL && cur->next->data < x)
        cur = cur->next;             /* 找到第一个 >= x 的前驱 */
    p->next = cur->next;
    cur->next = p;
    return dummy.next;
}

void print_list(Node *head)
{
    for (; head != NULL; head = head->next) printf("%d ", head->data);
    printf("\n");
}

int main(void)
{
    Node *head = NULL;
    int a[5] = {3, 1, 4, 2, 5}, i;
    for (i = 0; i < 5; i++)
        head = insert_sorted(head, a[i]);
    print_list(head);
    return 0;
}'''),

# ============ 第 17 章 数据结构：栈与队列 ============
(17, 1, "顺序栈", 1, "栈：后进先出、top 指针",
 '用数组实现栈（init/is_empty/is_full/push/pop），main 中依次压入 1、2、3 再全部弹出，观察输出顺序。',
 '3 2 1',
 r'''#include <stdio.h>
#define MAXSIZE 10

typedef struct { int data[MAXSIZE]; int top; } Stack;

void init(Stack *s)     { s->top = -1; }
int  is_empty(Stack *s) { return s->top == -1; }
int  is_full(Stack *s)  { return s->top == MAXSIZE - 1; }
int  push(Stack *s, int x)
{
    if (is_full(s)) return 0;
    s->data[++s->top] = x;
    return 1;
}
int  pop(Stack *s, int *x)
{
    if (is_empty(s)) return 0;
    *x = s->data[s->top--];
    return 1;
}

int main(void)
{
    Stack s;
    int x;
    init(&s);
    push(&s, 1); push(&s, 2); push(&s, 3);
    while (pop(&s, &x)) printf("%d ", x);   /* 后进先出 */
    printf("\n");
    return 0;
}'''),

(17, 2, "十进制转二进制（栈应用）", 2, "整除取余 + 栈的逆序特性",
 '输入一个非负整数，利用栈“后进先出”的特性把它转成二进制输出。提示：不断 n%2 入栈、n/=2，最后依次出栈。',
 '输入: 13\n输出: 1101',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#define MAXSIZE 32

typedef struct { int data[MAXSIZE]; int top; } Stack;

void push(Stack *s, int x) { s->data[++s->top] = x; }
int  pop(Stack *s)         { return s->data[s->top--]; }
int  is_empty(Stack *s)    { return s->top == -1; }

int main(void)
{
    Stack s;
    int n;
    s.top = -1;
    scanf("%d", &n);
    if (n == 0) { printf("0\n"); return 0; }
    while (n > 0) {
        push(&s, n % 2);   /* 余数进栈 */
        n /= 2;
    }
    while (!is_empty(&s)) printf("%d", pop(&s));
    printf("\n");
    return 0;
}
/* 解析：余数是先算出低位、后算出高位，而输出要高位在前，
   正好利用栈把顺序反过来 */'''),

(17, 3, "括号匹配", 3, "栈的经典应用",
 '输入一个只含 ()[]{} 的字符串，用栈判断括号是否匹配。注意三种不匹配情况：右括号多了、类型对不上、左括号多了。',
 '输入: {[( )]} 去掉空格即 {[(...)]}\n输出: 匹配',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

int main(void)
{
    char s[100], stack[100];
    int top = -1, i, ok = 1;
    char c;
    scanf("%99s", s);
    for (i = 0; s[i] != '\0' && ok; i++) {
        if (s[i]=='(' || s[i]=='[' || s[i]=='{') {
            stack[++top] = s[i];               /* 左括号进栈 */
        } else {
            if (top == -1) { ok = 0; break; }  /* 右括号多了 */
            c = stack[top--];                  /* 取出最近的左括号 */
            if ((s[i]==')' && c!='(') ||
                (s[i]==']' && c!='[') ||
                (s[i]=='}' && c!='{')) ok = 0; /* 类型对不上 */
        }
    }
    if (top != -1) ok = 0;                     /* 左括号多了 */
    printf(ok ? "匹配\n" : "不匹配\n");
    return 0;
}'''),

(17, 4, "循环队列", 4, "队：先进先出、取模回绕、判满判空",
 '用数组实现循环队列（牺牲一个存储单元区分队空和队满），实现 init/is_empty/is_full/enqueue/dequeue，并演示：入队 1~5，出队 2 个，再入队 6、7，依次出队输出。',
 '',
 r'''#include <stdio.h>
#define MAXSIZE 8

typedef struct { int data[MAXSIZE]; int front, rear; } Queue;

void init(Queue *q)     { q->front = q->rear = 0; }
int  is_empty(Queue *q) { return q->front == q->rear; }
int  is_full(Queue *q)  { return (q->rear + 1) % MAXSIZE == q->front; }
int  enqueue(Queue *q, int x)
{
    if (is_full(q)) return 0;
    q->data[q->rear] = x;
    q->rear = (q->rear + 1) % MAXSIZE;   /* 取模回绕 */
    return 1;
}
int  dequeue(Queue *q, int *x)
{
    if (is_empty(q)) return 0;
    *x = q->data[q->front];
    q->front = (q->front + 1) % MAXSIZE;
    return 1;
}

int main(void)
{
    Queue q;
    int x;
    init(&q);
    enqueue(&q, 1); enqueue(&q, 2); enqueue(&q, 3);
    enqueue(&q, 4); enqueue(&q, 5);
    dequeue(&q, &x); dequeue(&q, &x);    /* 出队 1 2，腾出空间 */
    enqueue(&q, 6); enqueue(&q, 7);      /* rear 回绕到数组开头 */
    while (dequeue(&q, &x)) printf("%d ", x);   /* 3 4 5 6 7 */
    printf("\n");
    return 0;
}'''),

(17, 5, "两个栈模拟队列", 5, "经典面试题：栈与队列互换",
 '用两个栈实现一个队列：入队压入栈 in；出队时若栈 out 为空，把 in 全部倒入 out 再弹出。演示入队 1、2、3，出队一次，再入队 4，然后连续出队，验证顺序正确。',
 '',
 r'''#include <stdio.h>
#define MAXSIZE 100

typedef struct { int data[MAXSIZE]; int top; } Stack;

void push(Stack *s, int x) { s->data[++s->top] = x; }
int  pop(Stack *s)         { return s->data[s->top--]; }
int  is_empty(Stack *s)    { return s->top == -1; }

typedef struct { Stack in, out; } Queue;

void enqueue(Queue *q, int x) { push(&q->in, x); }

int dequeue(Queue *q)
{
    if (is_empty(&q->out)) {
        while (!is_empty(&q->in))
            push(&q->out, pop(&q->in));   /* 倒腾一次，顺序翻转 */
    }
    if (is_empty(&q->out)) return -1;     /* 队列为空 */
    return pop(&q->out);
}

int main(void)
{
    Queue q;
    q.in.top = q.out.top = -1;
    enqueue(&q, 1); enqueue(&q, 2); enqueue(&q, 3);
    printf("%d ", dequeue(&q));    /* 1 */
    enqueue(&q, 4);
    printf("%d ", dequeue(&q));    /* 2 */
    printf("%d\n", dequeue(&q));   /* 3 */
    return 0;
}'''),

# ============ 第 18 章 排序与查找 ============
(18, 1, "冒泡排序", 1, "相邻交换、每轮冒出最大值",
 '写函数 void bubble_sort(int a[], int n) 升序排序，main 中输入 10 个数排序后输出。',
 '',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

void bubble_sort(int a[], int n)
{
    int i, j;
    for (i = 0; i < n - 1; i++)
        for (j = 0; j < n - 1 - i; j++)    /* 每轮少比一次 */
            if (a[j] > a[j + 1]) {
                int t = a[j]; a[j] = a[j + 1]; a[j + 1] = t;
            }
}

int main(void)
{
    int a[10], i;
    for (i = 0; i < 10; i++) scanf("%d", &a[i]);
    bubble_sort(a, 10);
    for (i = 0; i < 10; i++) printf("%d ", a[i]);
    printf("\n");
    return 0;
}'''),

(18, 2, "选择排序", 2, "每轮选最小、放前面",
 '实现 void selection_sort(int a[], int n)：每轮从无序区选出最小值，与无序区第一个元素交换。',
 '',
 r'''#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

void selection_sort(int a[], int n)
{
    int i, j, min, t;
    for (i = 0; i < n - 1; i++) {
        min = i;                       /* 假设无序区第一个最小 */
        for (j = i + 1; j < n; j++)
            if (a[j] < a[min]) min = j;
        if (min != i) { t = a[i]; a[i] = a[min]; a[min] = t; }
    }
}

int main(void)
{
    int a[6] = {5, 2, 9, 1, 7, 3}, i;
    selection_sort(a, 6);
    for (i = 0; i < 6; i++) printf("%d ", a[i]);
    printf("\n");
    return 0;
}'''),

(18, 3, "插入排序", 3, "扑克牌式插入",
 '实现 void insertion_sort(int a[], int n)：像整理扑克牌一样，把每个新元素插入到前面已有序部分的正确位置。',
 '',
 r'''#include <stdio.h>

void insertion_sort(int a[], int n)
{
    int i, j, key;
    for (i = 1; i < n; i++) {
        key = a[i];                      /* 待插入的牌 */
        for (j = i - 1; j >= 0 && a[j] > key; j--)
            a[j + 1] = a[j];             /* 比它大的都往后挪 */
        a[j + 1] = key;                  /* 放进空出的位置 */
    }
}

int main(void)
{
    int a[6] = {5, 2, 9, 1, 7, 3}, i;
    insertion_sort(a, 6);
    for (i = 0; i < 6; i++) printf("%d ", a[i]);
    printf("\n");
    return 0;
}'''),

(18, 4, "二分查找", 4, "有序数组折半查找、循环边界",
 '写函数 int binary_search(int a[], int n, int key)：在升序数组中查找 key，返回下标，找不到返回 -1。注意循环条件是 low <= high。',
 '',
 r'''#include <stdio.h>

int binary_search(int a[], int n, int key)
{
    int low = 0, high = n - 1, mid;
    while (low <= high) {              /* 注意：带等号 */
        mid = (low + high) / 2;
        if (a[mid] == key)     return mid;
        else if (a[mid] > key) high = mid - 1;
        else                   low = mid + 1;
    }
    return -1;
}

int main(void)
{
    int a[8] = {1, 3, 5, 7, 9, 11, 13, 15};
    printf("%d\n", binary_search(a, 8, 7));    /* 3 */
    printf("%d\n", binary_search(a, 8, 8));    /* -1 */
    return 0;
}'''),

(18, 5, "学生成绩排名", 5, "结构体 + 排序 + 名次（并列处理）",
 '给定 4 名学生（姓名+分数），按分数从高到低排序，输出名次、姓名、分数。分数相同名次并列（如两人并列第 1，下一个是第 3 名）。',
 '',
 r'''#include <stdio.h>

typedef struct { char name[20]; int score; } Student;

int main(void)
{
    Student s[4] = {{"Tom",85},{"Jerry",92},{"Mary",92},{"Bob",78}};
    int i, j, n = 4, rank = 1;
    for (i = 0; i < n - 1; i++)                 /* 冒泡：降序 */
        for (j = 0; j < n - 1 - i; j++)
            if (s[j].score < s[j + 1].score) {
                Student t = s[j]; s[j] = s[j + 1]; s[j + 1] = t;
            }
    for (i = 0; i < n; i++) {
        if (i > 0 && s[i].score != s[i - 1].score)
            rank = i + 1;                       /* 分数变了名次才变 */
        printf("第%d名 %s %d\n", rank, s[i].name, s[i].score);
    }
    return 0;
}'''),

# ============ 第 19 章 Linux 工具链与系统调用 ============
(19, 1, "常用命令闯关", 1, "Linux 基本命令",
 '操作题（在 Linux 终端或 WSL 中完成）：新建目录并进入、新建文件、复制、重命名、删除、查看文件内容、在文件里查找关键字、查看进程、给脚本加执行权限。把每一步用的命令记录下来。',
 '',
 r'''# 参考命令清单（在 Linux 终端逐条完成）：
mkdir test && cd test     # 建目录并进入
touch a.c                 # 新建空文件
cp a.c b.c                # 复制
mv b.c c.c                # 重命名（mv 还能移动文件）
rm c.c                    # 删除
cat /etc/hostname         # 查看文件内容
grep -n "int" main.c      # 查找关键字并显示行号
ps aux | grep bash        # 查看进程（配合管道）
chmod +x run.sh           # 加可执行权限
tar -czf backup.tar.gz .  # 打包当前目录'''),

(19, 2, "gcc 多文件编译", 2, "gcc 编译四步骤、-Wall -g",
 '把第 14 章“头文件三件套”的工程（utils.c/utils.h/main.c）拷到 Linux 下：先分步编译（-c 各自生成 .o，再链接成 app），再用一步到位的命令带 -Wall -g 重新编译并运行。',
 '',
 r'''# 假设工程有 main.c utils.c utils.h
gcc -c utils.c            # 只编译，生成 utils.o
gcc -c main.c             # 生成 main.o
gcc -o app main.o utils.o # 链接成可执行文件 app
./app                     # 运行

# 一步到位（日常推荐写法）：
gcc -Wall -g -o app main.c utils.c
# -Wall 打开所有警告（务必养成习惯）
# -g 生成 gdb 调试信息'''),

(19, 3, "gdb 调试入门", 3, "断点、单步、查看变量、调用栈",
 '操作题：故意写一个会数组越界/段错误的程序，用 gdb 调试它。要求完成：设断点、运行、单步、打印变量、崩溃后用 bt 看调用栈。记录完整的 gdb 会话命令。',
 '',
 r'''gcc -g -o app main.c       # 必须带 -g 才能调试
gdb ./app
(gdb) break main           # 在 main 设断点，可简写 b main
(gdb) run                  # 运行到断点
(gdb) next                 # 单步（不进函数），简写 n
(gdb) step                 # 单步（进入函数），简写 s
(gdb) print x              # 查看变量值，简写 p
(gdb) bt                   # 段错误时看调用栈，定位崩溃点
(gdb) quit
# 目标：以后遇到段错误不再害怕，bt + 行号就能定位'''),

(19, 4, "第一个 Makefile", 4, "目标/依赖/命令、Tab 缩进",
 '为三文件工程手写 Makefile：支持 make 一键编译、make clean 清理。注意命令行前必须是 Tab 缩进。',
 '',
 r'''# Makefile（文件名就叫 Makefile）
app: main.o utils.o
	gcc -o app main.o utils.o

main.o: main.c utils.h
	gcc -c main.c

utils.o: utils.c utils.h
	gcc -c utils.c

clean:
	rm -f app main.o utils.o

# 注意：每条命令前面是一个 Tab 字符，不是空格（经典坑）
# make        一键编译
# make clean  清理'''),

(19, 5, "系统调用复制文件", 5, "open/read/write/close、文件描述符",
 '在 Linux 下用系统调用 open/read/write/close 实现文件复制（a.txt → b.txt），体会它与标准库 fopen/fread 的关系。这就是以后操作串口、传感器设备文件的基本套路。',
 '',
 r'''#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main(void)
{
    int fd1, fd2, n;
    char buf[1024];
    fd1 = open("a.txt", O_RDONLY);
    fd2 = open("b.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd1 < 0 || fd2 < 0) { printf("open 失败\n"); return 1; }
    while ((n = read(fd1, buf, sizeof(buf))) > 0)
        write(fd2, buf, n);
    close(fd1);
    close(fd2);
    return 0;
}'''),

# ============ 第 20 章 单片机入门（51 → STM32） ============
(20, 1, "点亮第一颗 LED", 1, "GPIO 输出、Keil C51、while(1)",
 '说明：本题需在 Keil C51 + Proteus 仿真或 51 开发板上完成（PC 上没有 reg52.h）。让接在 P2.0 引脚的 LED 常亮，并回答：为什么单片机程序最后一定要 while(1)?',
 '',
 r'''#include <reg52.h>       /* Keil C51 环境专用头文件 */

sbit LED1 = P2^0;        /* LED 接 P2.0，低电平点亮的接法 */

void main(void)
{
    LED1 = 0;            /* 输出低电平 → 点亮 */
    while (1);           /* 单片机程序没有“结束”，必须死循环 */
}
/* 前 16 周的 C 功底在这里全部兑现：sbit 只是 51 对
   “访问某一位”的语法扩展，逻辑上就是练习 15.1 的位操作 */'''),

(20, 2, "流水灯", 2, "移位运算、延时函数",
 '让 P2 口的 8 颗 LED 依次点亮形成流水效果。提示：初值 0xFE（1111 1110）表示第一颗亮，每轮左移一位并补 1，全灭后回到初值。',
 '',
 r'''#include <reg52.h>

void delay(unsigned int t)     /* 粗略软件延时 */
{
    unsigned int i, j;
    for (i = t; i > 0; i--)
        for (j = 110; j > 0; j--);
}

void main(void)
{
    unsigned char led = 0xFE;          /* 1111 1110：第一颗亮 */
    while (1) {
        P2 = led;
        delay(500);
        led = (unsigned char)((led << 1) | 0x01);  /* 左移补 1 */
        if (led == 0xFF) led = 0xFE;   /* 流完一圈重来 */
    }
}'''),

(20, 3, "按键控制 LED 翻转（消抖）", 3, "GPIO 输入、机械抖动、消抖三件套",
 '按一次按键，LED 状态翻转一次。要求实现完整的“延时消抖 + 二次确认 + 等待松手”三件套。',
 '',
 r'''#include <reg52.h>

sbit KEY  = P3^1;        /* 按键接 P3.1，按下为低电平 */
sbit LED1 = P2^0;

void delay(unsigned int t)
{
    unsigned int i, j;
    for (i = t; i > 0; i--)
        for (j = 110; j > 0; j--);
}

void main(void)
{
    while (1) {
        if (KEY == 0) {              /* 检测到按下 */
            delay(20);               /* 消抖：跳过机械抖动期 */
            if (KEY == 0) {          /* 二次确认真的按下了 */
                LED1 = !LED1;        /* 翻转 */
                while (KEY == 0);    /* 等待松手，防止连触发 */
            }
        }
    }
}'''),

(20, 4, "串口发送 Hello", 4, "串口配置流程、波特率",
 '配置 51 串口（9600 波特率，11.0592MHz 晶振），循环发送字符串 "Hello"。建议先跟江协视频串口章节再写。',
 '',
 r'''#include <reg52.h>

void uart_init(void)
{
    SCON = 0x50;     /* 串口方式1，允许接收 */
    TMOD = 0x20;     /* 定时器1方式2，作波特率发生器 */
    TH1  = 0xFD;     /* 9600 波特率 @11.0592MHz */
    TR1  = 1;        /* 启动定时器1 */
}

void uart_send_byte(unsigned char dat)
{
    SBUF = dat;
    while (TI == 0); /* 等待发送完成 */
    TI = 0;          /* 软件清零发送标志 */
}

void main(void)
{
    uart_init();
    while (1) {
        uart_send_byte('H');
        uart_send_byte('e');
        uart_send_byte('l');
        uart_send_byte('l');
        uart_send_byte('o');
    }
}
/* 串口是嵌入式最常用的调试与通信手段；STM32 的 USART 是它的
   升级版，配置流程（时钟→引脚→参数→收发）完全相通 */'''),

(20, 5, "STM32 预览：GPIO 点灯五步", 5, "标准库开发流程、时钟使能",
 '概念题（学完 51 后选做）：写出 STM32 标准库点灯的五个步骤，并给出 PC13 引脚推挽输出的初始化代码片段。对比 51：STM32 为什么多了一步“使能时钟”？',
 '',
 r'''/* 参考解答（标准库流程，理解为主）：
   STM32 点灯五步：
     1. 使能 GPIO 时钟   RCC_APB2PeriphClockCmd(...)
     2. 定义并填充 GPIO_InitTypeDef（引脚/模式/速度）
     3. GPIO_Init() 初始化为推挽输出
     4. GPIO_SetBits() 输出高 / GPIO_ResetBits() 输出低
     5. 主循环中延时翻转，形成闪烁
   STM32 低功耗设计：默认关闭外设时钟省电，用哪个外设
   就先给哪个开时钟——这是它比 51 多出来的一步。 */
#include "stm32f10x.h"

void LED_Init(void)
{
    GPIO_InitTypeDef gpio;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);  /* 步骤1 */
    gpio.GPIO_Pin   = GPIO_Pin_13;
    gpio.GPIO_Mode  = GPIO_Mode_Out_PP;                    /* 步骤2 */
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC, &gpio);                               /* 步骤3 */
}

int main(void)
{
    LED_Init();
    while (1) {
        GPIO_ResetBits(GPIOC, GPIO_Pin_13);   /* 步骤4：亮 */
        /* 此处应加 delay 函数 */
        GPIO_SetBits(GPIOC, GPIO_Pin_13);     /* 灭 */
        /* 此处应加 delay 函数 */
    }
}'''),
]

# ============================================================
# 生成工具函数
# ============================================================

def stars(d):
    return "★" * d + "☆" * (5 - d)


def chapter(ch):
    for c in CHAPTERS:
        if c[0] == ch:
            return c
    raise KeyError(ch)


def render_skeleton(entry):
    """生成单个 .c 练习骨架文件内容。"""
    ch, num, title, diff, knowledge, problem, sample, _code = entry
    lines = []
    lines.append("/*")
    lines.append("============================================================")
    lines.append("第 %d 章 · 习题 %d" % (ch, num))
    lines.append("题名：%s" % title)
    lines.append("难度：%s（%s）" % (stars(diff), DIFF_NAMES[diff]))
    lines.append("知识点：%s" % knowledge)
    lines.append("============================================================")
    lines.append("【题目】")
    lines.extend(problem.split("\n"))
    if sample:
        lines.append("")
        lines.append("【示例输出】")
        lines.extend(sample.split("\n"))
    lines.append("============================================================")
    lines.append("*/")
    lines.append("")
    lines.append("#include <stdio.h>")
    lines.append("")
    lines.append("int main(void)")
    lines.append("{")
    lines.append("    // 👉 在这里开始写你的代码")
    lines.append("    return 0;")
    lines.append("}")
    return "\n".join(lines) + "\n"


# ============================================================
# 输出 1：exercises/*.c
# ============================================================

def build_exercises():
    ex_dir = os.path.join(HERE, "exercises")
    os.makedirs(ex_dir, exist_ok=True)
    for entry in DATA:
        ch, num = entry[0], entry[1]
        path = os.path.join(ex_dir, "ch%02d_ex%02d.c" % (ch, num))
        with open(path, "w", encoding="utf-8-sig", newline="\n") as f:
            f.write(render_skeleton(entry))
    return len(DATA)


# ============================================================
# 输出 2：答案 PDF（与 Python 版同款排版）
# ============================================================

def build_pdf():
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import ParagraphStyle
        from reportlab.lib.units import cm
        from reportlab.lib import colors
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont
        from reportlab.pdfbase.cidfonts import UnicodeCIDFont
        from reportlab.platypus import (
            SimpleDocTemplate, Paragraph, Spacer, PageBreak,
            Preformatted, Table, TableStyle, HRFlowable,
        )
    except ImportError:
        print("[skip] reportlab not installed -> PDF skipped")
        return False

    # 字体：优先黑体文件，缺失时用内置 CID 字体兜底
    try:
        pdfmetrics.registerFont(TTFont("CJK", r"C:\Windows\Fonts\simhei.ttf"))
        pdfmetrics.registerFont(TTFont("CODE", r"C:\Windows\Fonts\simhei.ttf"))
    except Exception:
        pdfmetrics.registerFont(UnicodeCIDFont("CJK"))
        pdfmetrics.registerFont(UnicodeCIDFont("CODE"))

    PAGE = A4
    LEFT, RIGHT, TOP, BOT = 2.0 * cm, 2.0 * cm, 2.0 * cm, 2.0 * cm

    S_TITLE = ParagraphStyle("t", fontName="CJK", fontSize=24, leading=30,
                             alignment=1, textColor=colors.HexColor("#1e40af"), spaceAfter=10,
                             keepWithNext=True)
    S_SUB = ParagraphStyle("s", fontName="CJK", fontSize=12, leading=18,
                           alignment=1, textColor=colors.HexColor("#57606a"), spaceAfter=30)
    S_H1 = ParagraphStyle("h1", fontName="CJK", fontSize=18, leading=24,
                          textColor=colors.HexColor("#1e3a8a"), spaceBefore=6, spaceAfter=8,
                          keepWithNext=True)
    S_H2 = ParagraphStyle("h2", fontName="CJK", fontSize=13, leading=18,
                          textColor=colors.HexColor("#3b82f6"), spaceBefore=4, spaceAfter=4,
                          keepWithNext=True)
    S_BODY = ParagraphStyle("b", fontName="CJK", fontSize=10, leading=14,
                            textColor=colors.HexColor("#1f2328"))
    S_LABEL = ParagraphStyle("lbl", fontName="CJK", fontSize=10, leading=14,
                             textColor=colors.HexColor("#1f2328"), keepWithNext=True)
    S_TOC = ParagraphStyle("toc", fontName="CJK", fontSize=10, leading=13,
                           leftIndent=8, textColor=colors.HexColor("#1f2328"), spaceBefore=1)
    S_CODE = ParagraphStyle("c", fontName="CODE", fontSize=9, leading=12,
                            textColor=colors.HexColor("#1f2328"))

    def code_block(code):
        inner = Preformatted(code.replace("\t", "    "), S_CODE)
        tbl = Table([[inner]], colWidths=[PAGE[0] - LEFT - RIGHT])
        tbl.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#f8fafc")),
            ("BOX", (0, 0), (-1, -1), 0.25, colors.HexColor("#cbd5e1")),
            ("LEFTPADDING", (0, 0), (-1, -1), 8),
            ("RIGHTPADDING", (0, 0), (-1, -1), 8),
            ("TOPPADDING", (0, 0), (-1, -1), 6),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ]))
        return tbl

    def esc(text):
        text = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        import re
        text = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", text)
        return text.replace("\n", "<br/>")

    def footer(canvas, doc):
        canvas.saveState()
        canvas.setFont("CJK", 8)
        canvas.setFillColor(colors.HexColor("#9ca3af"))
        canvas.drawString(LEFT, BOT / 2, "C 语言嵌入式方向练习答案 · 100 题")
        canvas.drawRightString(PAGE[0] - RIGHT, BOT / 2, "第 %d 页" % doc.page)
        canvas.restoreState()

    out = os.path.join(HERE, "C语言_练习答案_100题.pdf")
    doc = SimpleDocTemplate(out, pagesize=PAGE, leftMargin=LEFT, rightMargin=RIGHT,
                            topMargin=TOP, bottomMargin=BOT,
                            title="C 语言编程练习答案 · 100 题")

    flow = []
    # 封面
    flow.append(Spacer(1, 4 * cm))
    flow.append(Paragraph("C 语言编程练习 · 参考答案", S_TITLE))
    flow.append(Paragraph("嵌入式 / 求职方向 · 100 题精解（20 章 × 5 题）", S_SUB))
    flow.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor("#cbd5e1"),
                           spaceBefore=10, spaceAfter=18))
    info = [
        ("题目总数", "100 题（20 章 × 5 题）"),
        ("难度区间", "1/5 入门 → 5/5 挑战"),
        ("章节覆盖", "Ch 1–20：从环境搭建到 51 单片机"),
        ("配套文件", "exercises/ 下 100 个 .c 练习骨架"),
        ("适配环境", "Windows + VS2022（第 19 章需 Linux/WSL，第 20 章需 Keil）"),
        ("生成工具", "Reportlab + SimHei 中文字体"),
    ]
    tbl = Table([[Paragraph("<b>%s</b>" % k, S_BODY), Paragraph(v, S_BODY)] for k, v in info],
                colWidths=[4 * cm, PAGE[0] - LEFT - RIGHT - 4 * cm])
    tbl.setStyle(TableStyle([
        ("LINEBELOW", (0, 0), (-1, -2), 0.25, colors.HexColor("#eaeef2")),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    flow.append(tbl)
    flow.append(Spacer(1, 1.2 * cm))
    flow.append(Paragraph(
        "<b>使用建议：</b>先在 exercises/ 对应的 .c 文件里自己写，卡住了再看本答案。"
        "答案不唯一，重点看思路；每题右上难度用 ★ 标记。",
        ParagraphStyle("note", fontName="CJK", fontSize=10, leading=15,
                       textColor=colors.HexColor("#1f2328"),
                       backColor=colors.HexColor("#fef3c7"), borderPadding=10,
                       borderColor=colors.HexColor("#f59e0b"), borderWidth=0.5)))
    flow.append(PageBreak())

    # 目录
    flow.append(Paragraph("目  录", S_TITLE))
    flow.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor("#cbd5e1"),
                           spaceBefore=4, spaceAfter=14))
    by_ch = {}
    for e in DATA:
        by_ch.setdefault(e[0], []).append(e)
    for ch, name, week, _v in CHAPTERS:
        flow.append(Paragraph("<b>第 %d 章 · %s</b>　<font color='#6e7781'>%s</font>" % (ch, name, week), S_H2))
        for e in by_ch[ch]:
            flow.append(Paragraph(
                "&nbsp;&nbsp;&nbsp;&nbsp;Q%02d.%02d&nbsp; %s&nbsp; <font color='#6e7781'>%s %s</font>"
                % (ch, e[1], e[2], stars(e[3]), DIFF_NAMES[e[3]]), S_TOC))
    flow.append(PageBreak())

    # 正文
    for ch, name, week, _v in CHAPTERS:
        flow.append(Paragraph("第 %d 章 · %s" % (ch, name), S_TITLE))
        flow.append(Paragraph("<font color='#6e7781'>%s</font>" % week, S_BODY))
        flow.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#3b82f6"),
                               spaceBefore=2, spaceAfter=14))
        for e in sorted(by_ch[ch], key=lambda x: x[1]):
            _ch, num, title, diff, knowledge, problem, sample, code = e
            flow.append(Paragraph(
                "<b>第 %d 章 · Q%02d</b> · <b>%s</b>　"
                "<font color='#94a3b8'>%s %s</font>" % (ch, num, title, stars(diff), DIFF_NAMES[diff]),
                S_H2))
            flow.append(Spacer(1, 4))
            flow.append(Paragraph("<b>【知识点】</b> " + esc(knowledge), S_LABEL))
            flow.append(Spacer(1, 2))
            flow.append(Paragraph("<b>【题目】</b> " + esc(problem), S_BODY))
            if sample:
                flow.append(Spacer(1, 2))
                flow.append(Paragraph("<b>【示例输出】</b> " + esc(sample), S_BODY))
            flow.append(Spacer(1, 6))
            flow.append(Paragraph("<b>【参考解答】</b>", S_LABEL))
            flow.append(code_block(code))
            flow.append(HRFlowable(width="80%", thickness=0.3, color=colors.HexColor("#eaeef2"),
                                   spaceBefore=10, spaceAfter=14, hAlign="CENTER"))
        flow.append(PageBreak())

    flow.append(Spacer(1, 5 * cm))
    flow.append(HRFlowable(width="60%", thickness=0.5, color=colors.HexColor("#cbd5e1"),
                           spaceBefore=0, spaceAfter=24, hAlign="CENTER"))
    flow.append(Paragraph("— 文档结束 · 共 100 道练习题 · 祝学习愉快 —",
                          ParagraphStyle("end", fontName="CJK", fontSize=11, leading=16,
                                         alignment=1, textColor=colors.HexColor("#6e7781"))))
    doc.build(flow, onFirstPage=footer, onLaterPages=footer)
    return True


# ============================================================
# 输出 3：重写主文件《C语言学习全流程.txt》
# ============================================================

GUIDE_HEAD = r"""====================================================================
        C 语言零基础自学全流程（嵌入式 / 求职方向 · 定制版 v2.0）
====================================================================
更新时间：2026-08-29（v2.0：仿照《入门代码集合》重构为 20 章 × 5 题）
适用对象：零基础，目标为嵌入式 / 底层开发岗位求职
每日投入：1~3 小时
总周期  ：约 16 周（4 个月），之后进入持续刷题 + 项目阶段

--------------------------------------------------------------------
【本套资料的三件套（配套使用）】
--------------------------------------------------------------------
1. 本文件《C语言学习全流程.txt》：总纲。学习路线、每章视频、
   100 题完整题目 + 参考解答、打卡表、面试题、FAQ。
2. 《C语言入门代码集合》文件夹里的 exercises/：
   100 个可直接编译的练习骨架文件（ch01_ex01.c ~ ch20_ex05.c），
   每个文件头部有题目说明，正文是待填空的 main 函数。
   推荐流程：看视频 → 打开对应骨架文件自己写 → 编译跑通
   → 对照本文件的参考解答或答案 PDF 复盘。
3. 《C语言_练习答案_100题.pdf》（在同一个文件夹里）：
   100 题的排版版参考答案，格式与 Python 版《入门代码集合》
   的答案手册一致，适合打印或平板阅读。

【使用说明】
1. 每章 = 视频学习 + 5 道练习（难度从 ★ 入门到 ★★★★★ 挑战）。
   建议时间分配：1/3 看视频，2/3 敲代码；看懂 ≠ 会写。
2. 练习题先自己写，写不出来再看答案；看完答案后合上文件重写。
3. 洛谷在线刷题作为每章的补充巩固（提交语言选 C）。
4. 文末附录 C 有全部视频链接汇总，均已核实可直接点开。
"""

GUIDE_TAIL = r"""====================================================================
[综合项目] 简历项目（第 12 周与第 16 周收尾时做）
====================================================================

项目一【★★★】通讯录管理系统（对应第 11/13/14 章，第 12 周）
  需求：
    1) 结构体保存联系人：姓名、电话、城市。
    2) 菜单：① 添加 ② 按姓名删除 ③ 按姓名查找 ④ 修改电话
       ⑤ 显示全部 ⑥ 按姓名排序 ⑦ 退出。
    3) 数据保存到 contacts.txt，重启不丢（第 13 章知识）。
    4) 拆分为 contact.h / contact.c / main.c（第 14 章知识）。
  进阶：把静态数组改成 malloc 动态扩容，或改成链表存储。
  验收：7 个功能全部可用；异常输入不崩溃；重启数据不丢。

项目二【★★★】51 电子时钟（对应第 20 章，第 16 周）
  需求：数码管显示 时:分:秒；按键可调时/分；选做整点报时蜂鸣。
  提示：用定时器中断计时；按键用“消抖三件套 + 状态机”处理。
  （备选：温度传感器采集 + 串口上报 PC。）

====================================================================
[附录 A] 16 周打卡进度表（每完成一项打 √）
====================================================================
  周 1  □ 第 1 章  初识 C 与开发环境（3 道练习起步）
  周 2  □ 第 2 章  变量、数据类型与输入输出
  周 3  □ 第 3 章  运算符与表达式      □ 第 4 章  分支结构
  周 4  □ 第 5 章  循环结构
  周 5  □ 第 6 章  函数与递归
  周 6  □ 第 7 章  数组
  周 7  □ 第 8 章  字符串与字符处理
  周 8  □ 第 9 章  指针基础
  周 9  □ 第 10 章 指针进阶            □ 第 15 章 关键字与位运算
  周10  □ 第 11 章 结构体、联合与枚举
  周11  □ 第 12 章 动态内存管理        □ 第 13 章 文件操作
  周12  □ 第 14 章 多文件工程          □ 项目一：通讯录完成并验收
  周13  □ 第 16 章 数据结构：链表
  周14  □ 第 17 章 栈与队列            □ 第 18 章 排序与查找
  周15  □ 第 19 章 Linux 工具链与系统调用
  周16  □ 第 20 章 单片机入门          □ 项目二：51 电子时钟
  之后  □ 求职冲刺：面试 15 题 + 牛客 TOP101 + STM32 进阶

====================================================================
[附录 B] 嵌入式 C 高频面试 15 题（每题都能口头答 + 手写）
====================================================================
  1)  static 的三种用法？
  2)  const 与 #define 的区别？
  3)  volatile 的作用与三个使用场景？
  4)  写代码判断大小端（联合体法 / 指针法）？
  5)  程序的内存分区？全局变量、static 变量、局部变量、
      malloc 的内存、字符串常量分别在哪？
  6)  指针和数组的区别？sizeof 的差异？
  7)  strlen 与 sizeof 的区别？
  8)  结构体内存对齐规则？
  9)  malloc/free 使用注意事项？什么是内存泄漏？
  10) 位操作：某位置 1 / 清 0 / 翻转 / 判断？
  11) 函数指针是什么？回调在嵌入式中的应用？
  12) 手写 strcpy / memcpy（重叠区 → memmove 思想）？
  13) 全局变量和局部变量的生命周期与作用域？
  14) 递归的优缺点？栈溢出是怎么回事？
  15) 中断服务函数为什么不能太长、共享变量为什么加 volatile？
  （以上每题都在本文件的 100 题里有对应的练习，按章节回看。）

====================================================================
[附录 C] 常见错误 FAQ（新手 90% 的坑都在这里）
====================================================================
Q1 VS 里 scanf 报错 C4996？
  文件第一行加 #define _CRT_SECURE_NO_WARNINGS 1
Q2 程序闪退看不到结果？
  用 Ctrl+F5 运行；或在 return 前加 system("pause")（VS）。
Q3 scanf 忘写 &？
  scanf("%d", x) 错 → scanf("%d", &x) 对（数组名除外）。
Q4 中文分号/引号导致一堆报错？
  输入法切回英文再写代码；从第一条报错开始看。
Q5 = 和 == 混用？
  if (a = 5) 是赋值恒真，应为 if (a == 5)。开 -Wall 能查出来。
Q6 数组越界？
  C 不检查下标，越界可能“看起来没事”但埋雷；循环条件反复确认。
Q7 字符串没有 '\0'？
  手动构造字符串必须补 '\0'，否则 strlen/printf 读到天边。
Q8 指针未初始化就解引用（野指针）？
  定义指针时立刻指向有效地址或置 NULL。
Q9 malloc 忘 free / free 后继续用？
  养成“谁申请谁释放、free 后置 NULL”习惯。
Q10 浮点数用 == 比较？
  浮点有误差，应比较 fabs(a-b) < 1e-6。
Q11 整数除法陷阱？
  5/2=2；想得 2.5 要写 5.0/2 或 (double)5/2。
Q12 多文件工程改了不生效？
  改了 .c 忘保存/没重新编译；多文件改动后要整体重新构建。

====================================================================
[附录 D] 视频资源与链接汇总（已核实可直接点开）
====================================================================
[视频课程]
1  鹏哥C语言2024完整版（主干）
   https://www.bilibili.com/video/BV1Vm4y1r7jY/
2  黑马程序员C语言零基础入门到精通（备选主干）
   https://www.bilibili.com/video/BV1Xa4y1k7LU/
3  浙大翁恺C语言 B站完整录像（入门+进阶）
   https://www.bilibili.com/video/BV1XZ4y1S7e1/
4  翁恺《程序设计入门——C语言》MOOC
   https://www.icourse163.org/learn/ZJU-199001
5  翁恺《C语言程序设计（进阶）》MOOC
   https://www.icourse163.org/learn/ZJU-9001
6  王道数据结构
   https://www.bilibili.com/video/BV1b7411N798/
7  韩顺平《一周学会Linux》
   https://www.bilibili.com/video/BV1Sv411r7vd/
8  江协科技 51单片机入门教程
   https://www.bilibili.com/video/BV1Mb411e7re/
9  江协科技 STM32入门教程（进阶主线）
   https://www.bilibili.com/video/BV1th411z7sn/
10 江协科技官网（配套资料下载）
   https://jiangxiekeji.com/
[在线刷题]
11 洛谷题单广场            https://www.luogu.com.cn/training/list
12 洛谷入门1顺序结构       https://www.luogu.com.cn/training/100
13 洛谷入门3循环结构       https://www.luogu.com.cn/training/102
14 洛谷入门6函数与结构体   https://www.luogu.com.cn/training/105
15 牛客面试TOP101题单      https://www.nowcoder.com/exam/oj
16 牛客公司真题/面试题库   https://www.nowcoder.com/exam/interview
17 力扣题库（选做）        https://leetcode.cn/problemset/all/
[软件下载]
18 VS2022 社区版   https://visualstudio.microsoft.com/zh-hans/vs/community/
19 Dev-C++         https://sourceforge.net/projects/embarcadero-devcpp/
20 VS Code         https://code.visualstudio.com/
21 MSYS2/MinGW     https://www.msys2.org/

====================================================================
        祝学习顺利！坚持 16 周，你会遇见一个完全不同的自己。
====================================================================
"""

ONLINE_EXTRA = r"""  在线刷题巩固（本章学完选做）：
"""


def build_guide():
    out = []
    out.append(GUIDE_HEAD.rstrip("\n"))
    out.append("")
    out.append("=" * 68)
    out.append("【20 章路线总览】")
    out.append("=" * 68)
    for ch, name, week, video in CHAPTERS:
        out.append("第 %2d 章  %-22s %s" % (ch, name, week))
    out.append("")
    out.append("总览之后是每章 5 道练习的完整内容（题目 + 参考解答）。")
    out.append("")

    for ch, name, week, video in CHAPTERS:
        out.append("=" * 68)
        out.append("第 %d 章 · %s（%s）" % (ch, name, week))
        out.append("视频：%s" % video)
        out.append("=" * 68)
        for e in [x for x in DATA if x[0] == ch]:
            _ch, num, title, diff, knowledge, problem, sample, code = e
            out.append("-" * 68)
            out.append("第 %d 章 · 习题 %d" % (ch, num))
            out.append("题名：%s" % title)
            out.append("难度：%s（%s）" % (stars(diff), DIFF_NAMES[diff]))
            out.append("知识点：%s" % knowledge)
            out.append("-" * 68)
            out.append("【题目】")
            out.append(problem)
            if sample:
                out.append("")
                out.append("【示例输出】")
                out.append(sample)
            out.append("")
            out.append("【参考解答】")
            for ln in code.split("\n"):
                out.append("    " + ln)
            out.append("")
        out.append("")

    out.append(GUIDE_TAIL.rstrip("\n"))
    out.append("")

    path = os.path.join(WORKSPACE, "C语言学习全流程.txt")
    with open(path, "w", encoding="utf-8-sig", newline="\n") as f:
        f.write("\n".join(out))
    return path


# ============================================================
# 输出 4：README
# ============================================================

README = """C 语言入门代码集合（仿 Python 版《入门代码集合》结构）
============================================================

结构：
  exercises/                 100 个练习骨架（ch01_ex01.c ~ ch20_ex05.c）
                             头部注释 = 题目；正文 = 待填空的 main
  C语言_练习答案_100题.pdf   100 题排版版参考答案（20 章 × 5 题）
  build_all.py               一键重新生成以上内容的脚本
  README.txt                 本说明

配套总纲：
  上级目录的《C语言学习全流程.txt》包含学习路线、每章视频链接、
  100 题题目与参考解答全文、打卡表、面试题、FAQ。

使用方法：
  1. 看当前章节的 B 站视频（链接见总纲）；
  2. 打开 exercises/ 里对应章节的 .c 骨架，自己把代码补全；
  3. 编译运行通过后，对照答案 PDF 或总纲里的【参考解答】复盘；
  4. 每章 5 题难度递增，★ 入门 → ★★★★★ 挑战。

环境说明：
  第 1~18 章在 Windows + VS2022（或 Dev-C++/VSCode+MinGW）完成；
  第 19 章需要 Linux（虚拟机或 WSL2）；
  第 20 章需要 Keil C51 + 开发板/Proteus 仿真。

重新生成（修改 build_all.py 里的数据后）：
  python build_all.py
"""

DIFF_DIST_NOTE = ""  # 保留位


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    n = build_exercises()
    print("[ok] exercises: %d 个骨架文件已生成" % n)
    pdf_ok = build_pdf()
    if pdf_ok:
        size = os.path.getsize(os.path.join(HERE, "C语言_练习答案_100题.pdf")) // 1024
        print("[ok] pdf: C语言_练习答案_100题.pdf 已生成 (%d KB)" % size)
    gpath = build_guide()
    print("[ok] guide: %s 已重写" % gpath)
    with open(os.path.join(HERE, "README.txt"), "w", encoding="utf-8-sig", newline="\n") as f:
        f.write(README)
    print("[ok] README.txt 已生成")
    print("[done] 全部完成")


if __name__ == "__main__":
    main()
